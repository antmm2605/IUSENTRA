"""
PCT - Processo Civile Telematico
Sistema per l'invio telematico negli studi legali italiani.
"""

__version__ = "2.35.2"
__author__ = "Studio Legale"
