"""
Interfaccia a riga di comando per il sistema PCT.
"""

import os
import sys
import json
from pathlib import Path
from typing import Optional

import click

from . import __version__
from .busta import DatiBusta, Allegato
from .pec import ConfigPEC
from .deposito import DepositoCivile, DepositoPenale
from .notifica import NotificaTelematica, RelataDiNotifica
from .reginde import ClientReGINde
from .firma import FirmaDigitale
from .agenda import Agenda, TipoAppuntamento, StatoAppuntamento
from .clienti import (
    GestioneClienti,
    TipoCliente,
    StatoCliente,
    RiferimentoProcedimento,
)
from .fascicoli import (
    GestioneFascicoli,
    TipoFascicolo,
    StatoFascicolo,
    TipoAttivita,
    EsitoAttivita,
)
from .messaggi import (
    GestioneMessaggi,
    CanaleMsggio,
    ConfigMessaggistica,
    ConfigEmail,
    ConfigTwilio,
)
from .backup import (
    GestioneBackup,
    TipoBackup,
    StatoBackup,
    FrequenzaBackup,
)
from .auth import (
    GestioneUtenti,
    RuoloUtente,
)
from .scadenziario import (
    GestioneScadenziario,
    TipoTermine,
    StatoTermine,
    PRESET_TERMINI,
    calcola_termine,
)


def carica_config(config_path: str | None = None) -> dict:
    """
    Carica la configurazione da config/studio.json (priorità) o da variabili d'ambiente.
    Il percorso del file può essere sovrascritto tramite PCT_STUDIO_CONFIG.
    """
    path = config_path or os.getenv("PCT_STUDIO_CONFIG", "./config/studio.json")
    try:
        from .config_studio import GestioneConfigStudio
        gs = GestioneConfigStudio(path)
        c = gs.config
    except Exception:
        c = None

    def _v(from_cfg, env_key, default=""):
        """Restituisce from_cfg se non vuoto, altrimenti env var, altrimenti default."""
        if from_cfg:
            return from_cfg
        return os.getenv(env_key, default)

    return {
        "pec_indirizzo":  _v(c and c.pec.indirizzo,  "PCT_PEC_INDIRIZZO"),
        "pec_password":   _v(c and c.pec.password,   "PCT_PEC_PASSWORD"),
        "pec_smtp_host":  _v(c and c.pec.smtp_host,  "PCT_PEC_SMTP_HOST", "smtp.pec.aruba.it"),
        "pec_smtp_port":  (c and c.pec.smtp_port) or int(os.getenv("PCT_PEC_SMTP_PORT", "465")),
        "pec_imap_host":  _v(c and c.pec.imap_host,  "PCT_PEC_IMAP_HOST", "imaps.pec.aruba.it"),
        "firma_p12":      _v(c and c.firma.p12_path,  "PCT_FIRMA_P12"),
        "firma_password": _v(c and c.firma.password,  "PCT_FIRMA_PASSWORD"),
        "cf_avvocato":    _v(c and (c.studio.codice_fiscale_avvocato or c.firma.cf_avvocato),
                            "PCT_CF_AVVOCATO"),
        "nome_avvocato":  _v(c and c.studio.avvocato, "PCT_NOME_AVVOCATO"),
        "output_dir":     os.getenv("PCT_OUTPUT_DIR", "./depositi"),
    }


@click.group()
@click.version_option(__version__)
def cli():
    """PCT - Sistema di deposito telematico per studi legali italiani."""
    pass


@cli.command("deposita")
@click.option("--atto", required=True, type=click.Path(exists=True), help="Atto principale (PDF/A)")
@click.option("--tribunale", required=True, help="Nome tribunale (es. MILANO, ROMA)")
@click.option("--oggetto", required=True, help="Oggetto del deposito")
@click.option("--tipo-atto", default="MEMORIA", help="Tipo atto (RICORSO, MEMORIA, CITAZIONE...)")
@click.option("--allegato", multiple=True, type=click.Path(exists=True), help="Allegati aggiuntivi")
@click.option("--rg", help="Numero RG (es. 1234/2024)")
@click.option("--no-firma", is_flag=True, default=False, help="Salta la firma digitale")
@click.option("--no-ricevute", is_flag=True, default=False, help="Non attendere ricevute")
def cmd_deposita(atto, tribunale, oggetto, tipo_atto, allegato, rg, no_firma, no_ricevute):
    """Deposita un atto telematicamente presso un tribunale."""
    config = carica_config()

    if not config["pec_indirizzo"]:
        click.echo("Errore: configurare PCT_PEC_INDIRIZZO nelle variabili d'ambiente.", err=True)
        sys.exit(1)

    config_pec = ConfigPEC(
        indirizzo=config["pec_indirizzo"],
        password=config["pec_password"],
        smtp_host=config["pec_smtp_host"],
        smtp_port=config["pec_smtp_port"],
        imap_host=config["pec_imap_host"],
    )

    firma = None
    if not no_firma and config["firma_p12"] and Path(config["firma_p12"]).exists():
        firma = FirmaDigitale(
            config["firma_p12"],
            config["firma_password"].encode(),
        )
        click.echo(f"Firma digitale caricata: {firma.intestatario}")

    allegati = [Allegato(percorso=a, descrizione=Path(a).stem) for a in allegato]

    numero_rg = anno_rg = None
    if rg and "/" in rg:
        numero_rg, anno_str = rg.split("/", 1)
        anno_rg = int(anno_str) if anno_str.isdigit() else None

    dati = DatiBusta(
        codice_ufficio="",
        codice_registro="CIVILE",
        oggetto=oggetto,
        tipo_atto=tipo_atto,
        atto_principale=atto,
        allegati=allegati,
        numero_rg=numero_rg,
        anno_rg=anno_rg,
        cf_mittente=config["cf_avvocato"],
        operatore=config["nome_avvocato"],
    )

    deposito = DepositoCivile(config_pec, firma=firma, output_dir=config["output_dir"])

    click.echo(f"Avvio deposito presso Tribunale di {tribunale}...")
    esito = deposito.deposita(dati, tribunale, attendi_ricevute=not no_ricevute)

    click.echo(f"\nEsito deposito:")
    click.echo(f"  ID:      {esito.id_deposito}")
    click.echo(f"  Stato:   {esito.stato}")
    click.echo(f"  PEC:     {esito.pec_destinatario}")
    click.echo(f"  Busta:   {esito.busta_path}")
    click.echo(f"  Messaggio: {esito.messaggio}")

    esito_path = deposito.salva_esito(esito)
    click.echo(f"\nEsito salvato in: {esito_path}")


@cli.command("notifica")
@click.option("--atto", required=True, type=click.Path(exists=True), help="Atto da notificare (PDF/A firmato)")
@click.option("--destinatario-pec", required=True, help="PEC del destinatario")
@click.option("--destinatario", required=True, help="Nome del destinatario")
@click.option("--cf-destinatario", required=True, help="Codice fiscale del destinatario")
@click.option("--procedimento", help="Numero di procedimento")
@click.option("--autorita", help="Autorità giudiziaria")
def cmd_notifica(atto, destinatario_pec, destinatario, cf_destinatario, procedimento, autorita):
    """Invia una notifica telematica via PEC."""
    config = carica_config()

    if not config["pec_indirizzo"]:
        click.echo("Errore: configurare PCT_PEC_INDIRIZZO.", err=True)
        sys.exit(1)

    config_pec = ConfigPEC(
        indirizzo=config["pec_indirizzo"],
        password=config["pec_password"],
        smtp_host=config["pec_smtp_host"],
        smtp_port=config["pec_smtp_port"],
        imap_host=config["pec_imap_host"],
    )

    relata = RelataDiNotifica(
        notificante=config["nome_avvocato"],
        cf_notificante=config["cf_avvocato"],
        pec_notificante=config["pec_indirizzo"],
        destinatario=destinatario,
        cf_destinatario=cf_destinatario,
        pec_destinatario=destinatario_pec,
        atto_notificato=Path(atto).name,
        data_ora=__import__("datetime").datetime.now().strftime("%d/%m/%Y %H:%M"),
        numero_procedimento=procedimento,
        autorita_giudiziaria=autorita,
    )

    notifica = NotificaTelematica(config_pec)

    click.echo(f"Invio notifica a {destinatario} ({destinatario_pec})...")
    esito = notifica.notifica(atto, destinatario_pec, relata)

    click.echo(f"\nEsito notifica:")
    click.echo(f"  Stato:   {esito['esito']}")
    click.echo(f"  Busta:   {esito.get('busta_path', 'N/A')}")
    click.echo(f"  Messaggio: {esito.get('messaggio', '')}")


@cli.command("cerca-pec")
@click.argument("tribunale")
def cmd_cerca_pec(tribunale):
    """Cerca l'indirizzo PEC di un tribunale."""
    reginde = ClientReGINde()
    ufficio = reginde.cerca_ufficio_giudiziario(tribunale)
    if ufficio:
        click.echo(f"Tribunale: {ufficio.nome}")
        click.echo(f"Distretto: {ufficio.distretto}")
        click.echo(f"PEC:       {ufficio.pec}")
        click.echo(f"Codice:    {ufficio.codice}")
    else:
        click.echo(f"Tribunale '{tribunale}' non trovato.", err=True)
        sys.exit(1)


@cli.command("lista-tribunali")
def cmd_lista_tribunali():
    """Elenca i tribunali disponibili nel registro."""
    reginde = ClientReGINde()
    uffici = reginde.elenca_uffici()
    click.echo(f"{'Tribunale':<30} {'Codice':<12} {'PEC'}")
    click.echo("-" * 80)
    for ufficio in uffici:
        click.echo(f"{ufficio.nome:<30} {ufficio.codice:<12} {ufficio.pec}")


# ------------------------------------------------------------------ AGENDA

TIPI_VALIDI = [t.value for t in TipoAppuntamento]
STATI_VALIDI = [s.value for s in StatoAppuntamento]


def _agenda() -> Agenda:
    db = os.getenv("PCT_AGENDA_DB", "./agenda/appuntamenti.json")
    return Agenda(db_path=db)


def _fmt_app(a, verbose: bool = False) -> str:
    dt = a.data_ora_dt.strftime("%d/%m/%Y %H:%M")
    fine = a.fine_dt.strftime("%H:%M")
    riga = f"[{a.id}] {dt}-{fine}  {a.tipo.value:<14} {a.stato.value:<12} {a.titolo}"
    if verbose:
        if a.cliente:
            riga += f"\n         Cliente:      {a.cliente}"
        if a.procedimento:
            riga += f"\n         Procedimento: {a.procedimento}"
        if a.luogo:
            riga += f"\n         Luogo:        {a.luogo}"
        if a.note:
            riga += f"\n         Note:         {a.note}"
    return riga


@cli.group("agenda")
def grp_agenda():
    """Gestione agenda digitale dello studio."""
    pass


@grp_agenda.command("aggiungi")
@click.option("--titolo", required=True, help="Titolo dell'appuntamento")
@click.option("--tipo", required=True,
              type=click.Choice(TIPI_VALIDI, case_sensitive=False),
              help="Tipo appuntamento")
@click.option("--data-ora", required=True,
              help="Data e ora ISO 8601, es. 2024-03-15T10:00:00")
@click.option("--durata", default=60, show_default=True,
              help="Durata in minuti")
@click.option("--luogo", default="", help="Luogo / aula")
@click.option("--cliente", default="", help="Nome del cliente")
@click.option("--cf-cliente", default="", help="Codice fiscale cliente")
@click.option("--procedimento", default="", help="Numero RG o procedimento")
@click.option("--tribunale", default="", help="Tribunale di riferimento")
@click.option("--avvocato", default="", help="Avvocato responsabile")
@click.option("--note", default="", help="Note libere")
@click.option("--reminder", default=60, show_default=True,
              help="Reminder N minuti prima")
def cmd_aggiungi(titolo, tipo, data_ora, durata, luogo, cliente, cf_cliente,
                 procedimento, tribunale, avvocato, note, reminder):
    """Aggiunge un nuovo appuntamento all'agenda."""
    agenda = _agenda()
    try:
        app = agenda.aggiungi(
            titolo=titolo,
            tipo=TipoAppuntamento(tipo.upper()),
            data_ora=data_ora,
            durata_minuti=durata,
            luogo=luogo,
            cliente=cliente,
            cf_cliente=cf_cliente,
            procedimento=procedimento,
            tribunale=tribunale,
            avvocato=avvocato,
            note=note,
            reminder_minuti=reminder,
        )
        click.echo(f"Appuntamento aggiunto: {app.id}")
        click.echo(_fmt_app(app, verbose=True))
    except ValueError as e:
        click.echo(f"Errore: {e}", err=True)
        sys.exit(1)


@grp_agenda.command("lista")
@click.option("--oggi", is_flag=True, default=False, help="Solo appuntamenti di oggi")
@click.option("--settimana", is_flag=True, default=False, help="Questa settimana")
@click.option("--mese", is_flag=True, default=False, help="Questo mese")
@click.option("--tipo", type=click.Choice(TIPI_VALIDI, case_sensitive=False),
              default=None, help="Filtra per tipo")
@click.option("--stato", type=click.Choice(STATI_VALIDI, case_sensitive=False),
              default=None, help="Filtra per stato")
@click.option("--cliente", default=None, help="Filtra per nome cliente")
@click.option("-v", "--verbose", is_flag=True, default=False)
def cmd_lista(oggi, settimana, mese, tipo, stato, cliente, verbose):
    """Elenca appuntamenti in agenda."""
    from datetime import date as dt_date
    agenda = _agenda()
    oggi_d = dt_date.today()

    if oggi:
        apps = agenda.per_giorno(oggi_d)
    elif settimana:
        apps = agenda.per_settimana(oggi_d)
    elif mese:
        apps = agenda.per_mese(oggi_d.year, oggi_d.month)
    else:
        apps = agenda.tutti()

    if tipo:
        apps = [a for a in apps if a.tipo == TipoAppuntamento(tipo.upper())]
    if stato:
        apps = [a for a in apps if a.stato == StatoAppuntamento(stato.upper())]
    if cliente:
        apps = [a for a in apps if cliente.lower() in a.cliente.lower()]

    if not apps:
        click.echo("Nessun appuntamento trovato.")
        return

    click.echo(f"{'ID':<10} {'Data/Ora':<18} {'Tipo':<14} {'Stato':<12} Titolo")
    click.echo("-" * 80)
    for a in apps:
        click.echo(_fmt_app(a, verbose=verbose))


@grp_agenda.command("cerca")
@click.argument("testo")
@click.option("-v", "--verbose", is_flag=True, default=False)
def cmd_cerca(testo, verbose):
    """Cerca appuntamenti per testo libero."""
    agenda = _agenda()
    apps = agenda.cerca(testo=testo)
    if not apps:
        click.echo("Nessun risultato.")
        return
    for a in apps:
        click.echo(_fmt_app(a, verbose=verbose))


@grp_agenda.command("dettaglio")
@click.argument("id_app")
def cmd_dettaglio(id_app):
    """Mostra il dettaglio di un appuntamento."""
    agenda = _agenda()
    app = agenda.get(id_app.upper())
    if not app:
        click.echo(f"Appuntamento '{id_app}' non trovato.", err=True)
        sys.exit(1)
    click.echo(json.dumps(app.to_dict(), ensure_ascii=False, indent=2))


@grp_agenda.command("modifica")
@click.argument("id_app")
@click.option("--titolo", default=None)
@click.option("--data-ora", default=None)
@click.option("--durata", default=None, type=int)
@click.option("--luogo", default=None)
@click.option("--note", default=None)
@click.option("--cliente", default=None)
@click.option("--procedimento", default=None)
def cmd_modifica(id_app, **campi):
    """Modifica un appuntamento esistente."""
    agenda = _agenda()
    campi_puliti = {k.replace("-", "_"): v for k, v in campi.items() if v is not None}
    try:
        app = agenda.modifica(id_app.upper(), **campi_puliti)
        click.echo(f"Appuntamento {app.id} aggiornato.")
        click.echo(_fmt_app(app, verbose=True))
    except KeyError as e:
        click.echo(str(e), err=True)
        sys.exit(1)


@grp_agenda.command("stato")
@click.argument("id_app")
@click.argument("nuovo_stato", type=click.Choice(STATI_VALIDI, case_sensitive=False))
def cmd_stato(id_app, nuovo_stato):
    """Cambia lo stato di un appuntamento."""
    agenda = _agenda()
    try:
        app = agenda.cambia_stato(id_app.upper(), StatoAppuntamento(nuovo_stato.upper()))
        click.echo(f"Stato aggiornato: {app.stato.value}")
    except KeyError as e:
        click.echo(str(e), err=True)
        sys.exit(1)


@grp_agenda.command("elimina")
@click.argument("id_app")
@click.confirmation_option(prompt="Sei sicuro di voler eliminare questo appuntamento?")
def cmd_elimina(id_app):
    """Elimina un appuntamento."""
    agenda = _agenda()
    try:
        agenda.elimina(id_app.upper())
        click.echo(f"Appuntamento {id_app.upper()} eliminato.")
    except KeyError as e:
        click.echo(str(e), err=True)
        sys.exit(1)


@grp_agenda.command("reminder")
@click.option("--entro", default=60, show_default=True,
              help="Mostra reminder che scadono entro N minuti")
def cmd_reminder(entro):
    """Mostra gli appuntamenti con reminder imminente."""
    agenda = _agenda()
    apps = agenda.prossimi_reminder(entro_minuti=entro)
    if not apps:
        click.echo(f"Nessun reminder nei prossimi {entro} minuti.")
        return
    click.echo(f"Reminder imminenti (entro {entro} min):")
    for a in apps:
        minuti_mancanti = int(
            (a.data_ora_dt - __import__("datetime").datetime.now()).total_seconds() / 60
        )
        click.echo(f"  [{a.id}] tra {minuti_mancanti} min  — {a.titolo}")


@grp_agenda.command("statistiche")
def cmd_statistiche():
    """Mostra statistiche dell'agenda."""
    agenda = _agenda()
    stats = agenda.statistiche()
    click.echo(f"Totale appuntamenti: {stats['totale']}")
    click.echo(f"Oggi:                {stats['oggi']}")
    click.echo(f"Questa settimana:    {stats['questa_settimana']}")
    click.echo(f"Questo mese:         {stats['questo_mese']}")
    click.echo("\nPer tipo:")
    for tipo, n in stats["per_tipo"].items():
        if n:
            click.echo(f"  {tipo:<16} {n}")
    click.echo("\nPer stato:")
    for stato, n in stats["per_stato"].items():
        if n:
            click.echo(f"  {stato:<16} {n}")


# ================================================================ CLIENTI

def _clienti() -> GestioneClienti:
    db = os.getenv("PCT_CLIENTI_DB", "./clienti/anagrafica.json")
    return GestioneClienti(db_path=db)


def _fmt_cliente(c, verbose: bool = False) -> str:
    tipo = "PF" if c.tipo == TipoCliente.PERSONA_FISICA else "PG"
    cf = c.codice_fiscale or c.partita_iva or ""
    riga = f"[{c.id}] {c.nome_completo:<30} {tipo}  {c.stato.value:<12} {cf}"
    if verbose:
        if c.recapiti.cellulare or c.recapiti.telefono:
            riga += f"\n         Tel: {c.recapiti.cellulare or c.recapiti.telefono}"
        if c.recapiti.email:
            riga += f"\n         Email: {c.recapiti.email}"
        if str(c.indirizzo_residenza):
            riga += f"\n         Indirizzo: {c.indirizzo_residenza}"
        if c.avvocato_referente:
            riga += f"\n         Avv.: {c.avvocato_referente}"
        if c.procedimenti_attivi:
            proc = ", ".join(f"RG {p.numero_rg}/{p.anno}" for p in c.procedimenti_attivi)
            riga += f"\n         Procedimenti: {proc}"
    return riga


@cli.group("clienti")
def grp_clienti():
    """Gestione anagrafica clienti dello studio."""
    pass


@grp_clienti.command("nuovo")
@click.option("--tipo", type=click.Choice(["PF", "PG"], case_sensitive=False),
              required=True, help="PF=Persona fisica, PG=Persona giuridica")
@click.option("--nome", default="", help="Nome (persona fisica)")
@click.option("--cognome", default="", help="Cognome (persona fisica)")
@click.option("--ragione-sociale", default="", help="Ragione sociale (persona giuridica)")
@click.option("--cf", default="", help="Codice fiscale")
@click.option("--piva", default="", help="Partita IVA")
@click.option("--email", default="", help="Email")
@click.option("--cellulare", default="", help="Cellulare")
@click.option("--telefono", default="", help="Telefono fisso")
@click.option("--pec", default="", help="PEC")
@click.option("--avvocato", default="", help="Avvocato referente")
@click.option("--note", default="", help="Note")
def cmd_clienti_nuovo(tipo, nome, cognome, ragione_sociale, cf, piva,
                      email, cellulare, telefono, pec, avvocato, note):
    """Aggiunge un nuovo cliente all'anagrafica."""
    gc = _clienti()
    tipo_enum = TipoCliente.PERSONA_FISICA if tipo.upper() == "PF" else TipoCliente.PERSONA_GIURIDICA
    try:
        c = gc.nuovo(
            tipo=tipo_enum,
            nome=nome, cognome=cognome,
            ragione_sociale=ragione_sociale,
            codice_fiscale=cf, partita_iva=piva,
            avvocato_referente=avvocato, note=note,
        )
        if email or cellulare or telefono or pec:
            gc.aggiorna_recapiti(c.id, email=email, cellulare=cellulare,
                                 telefono=telefono, pec=pec)
        click.echo(f"Cliente aggiunto: {c.id}")
        click.echo(_fmt_cliente(c, verbose=True))
    except ValueError as e:
        click.echo(f"Errore: {e}", err=True)
        sys.exit(1)


@grp_clienti.command("lista")
@click.option("--stato", type=click.Choice([s.value for s in StatoCliente],
              case_sensitive=False), default="ATTIVO", show_default=True)
@click.option("--tipo", type=click.Choice(["PF", "PG"], case_sensitive=False),
              default=None)
@click.option("-v", "--verbose", is_flag=True, default=False)
def cmd_clienti_lista(stato, tipo, verbose):
    """Elenca i clienti in anagrafica."""
    gc = _clienti()
    stato_e = StatoCliente(stato) if stato else None
    tipo_e = (TipoCliente.PERSONA_FISICA if tipo and tipo.upper() == "PF"
              else TipoCliente.PERSONA_GIURIDICA if tipo else None)
    clienti = gc.tutti(stato=stato_e, tipo=tipo_e)
    if not clienti:
        click.echo("Nessun cliente trovato.")
        return
    click.echo(f"{'ID':<10} {'Nome':<30} {'Tipo'} {'Stato':<12} CF/P.IVA")
    click.echo("-" * 75)
    for c in clienti:
        click.echo(_fmt_cliente(c, verbose=verbose))


@grp_clienti.command("cerca")
@click.argument("testo")
@click.option("-v", "--verbose", is_flag=True, default=False)
def cmd_clienti_cerca(testo, verbose):
    """Cerca clienti per nome, CF, P.IVA, email o procedimento."""
    gc = _clienti()
    risultati = gc.cerca(testo=testo)
    if not risultati:
        click.echo("Nessun risultato.")
        return
    for c in risultati:
        click.echo(_fmt_cliente(c, verbose=verbose))


@grp_clienti.command("dettaglio")
@click.argument("id_cliente")
def cmd_clienti_dettaglio(id_cliente):
    """Mostra la scheda completa di un cliente."""
    gc = _clienti()
    c = gc.get(id_cliente.upper())
    if not c:
        click.echo(f"Cliente '{id_cliente}' non trovato.", err=True)
        sys.exit(1)
    click.echo(json.dumps(c.to_dict(), ensure_ascii=False, indent=2))


@grp_clienti.command("modifica")
@click.argument("id_cliente")
@click.option("--nome", default=None)
@click.option("--cognome", default=None)
@click.option("--cf", default=None)
@click.option("--email", default=None)
@click.option("--cellulare", default=None)
@click.option("--telefono", default=None)
@click.option("--avvocato", default=None)
@click.option("--note", default=None)
@click.option("--stato", type=click.Choice([s.value for s in StatoCliente],
              case_sensitive=False), default=None)
def cmd_clienti_modifica(id_cliente, nome, cognome, cf, email, cellulare,
                          telefono, avvocato, note, stato):
    """Modifica i dati di un cliente."""
    gc = _clienti()
    try:
        campi = {k: v for k, v in {
            "nome": nome, "cognome": cognome,
            "codice_fiscale": cf.upper() if cf else None,
            "avvocato_referente": avvocato, "note": note,
            "stato": StatoCliente(stato) if stato else None,
        }.items() if v is not None}
        if campi:
            gc.aggiorna(id_cliente.upper(), **campi)
        recapiti = {k: v for k, v in {
            "email": email, "cellulare": cellulare, "telefono": telefono
        }.items() if v is not None}
        if recapiti:
            gc.aggiorna_recapiti(id_cliente.upper(), **recapiti)
        c = gc.get(id_cliente.upper())
        click.echo(f"Cliente {c.id} aggiornato.")
        click.echo(_fmt_cliente(c, verbose=True))
    except KeyError as e:
        click.echo(str(e), err=True)
        sys.exit(1)


@grp_clienti.command("elimina")
@click.argument("id_cliente")
@click.confirmation_option(prompt="Sei sicuro di voler eliminare questo cliente?")
def cmd_clienti_elimina(id_cliente):
    """Elimina un cliente dall'anagrafica."""
    gc = _clienti()
    try:
        gc.elimina(id_cliente.upper())
        click.echo(f"Cliente {id_cliente.upper()} eliminato.")
    except KeyError as e:
        click.echo(str(e), err=True)
        sys.exit(1)


@grp_clienti.command("procedimento")
@click.argument("id_cliente")
@click.option("--rg", required=True, help="Numero RG (es. 1234)")
@click.option("--anno", type=int, default=None, help="Anno procedimento")
@click.option("--tribunale", default="", help="Tribunale competente")
@click.option("--descrizione", default="", help="Breve descrizione")
def cmd_clienti_procedimento(id_cliente, rg, anno, tribunale, descrizione):
    """Aggiunge un procedimento a un cliente."""
    import datetime
    gc = _clienti()
    try:
        proc = RiferimentoProcedimento(
            numero_rg=rg,
            anno=anno or datetime.date.today().year,
            tribunale=tribunale,
            descrizione=descrizione,
            data_apertura=datetime.date.today().isoformat(),
        )
        gc.aggiungi_procedimento(id_cliente.upper(), proc)
        click.echo(f"Procedimento RG {rg}/{anno or ''} aggiunto.")
    except KeyError as e:
        click.echo(str(e), err=True)
        sys.exit(1)


@grp_clienti.command("statistiche")
def cmd_clienti_statistiche():
    """Mostra statistiche dell'anagrafica clienti."""
    gc = _clienti()
    stats = gc.statistiche()
    click.echo(f"Totale clienti:           {stats['totale']}")
    click.echo(f"Con procedimenti attivi:  {stats['con_procedimenti_attivi']}")
    click.echo(f"Documenti scaduti:        {stats['documenti_scaduti']}")
    click.echo("\nPer tipo:")
    for t, n in stats["per_tipo"].items():
        if n:
            click.echo(f"  {t:<22} {n}")
    click.echo("\nPer stato:")
    for s, n in stats["per_stato"].items():
        if n:
            click.echo(f"  {s:<22} {n}")


# ================================================================ FASCICOLI

def _fascicoli() -> GestioneFascicoli:
    return GestioneFascicoli(
        db_path=os.getenv("PCT_FASCICOLI_DB", "./fascicoli/fascicoli.json"),
        documents_dir=os.getenv("PCT_FASCICOLI_DOCS", "./fascicoli/documenti"),
        archive_dir=os.getenv("PCT_FASCICOLI_ARCH", "./fascicoli/archivio"),
    )


def _fmt_fasc(f, verbose: bool = False) -> str:
    sc = f.prossima_scadenza
    sc_txt = f" | pross.scad: {sc.data}" if sc else ""
    riga = (f"[{f.id}] {f.numero}  {f.stato.value:<12} {f.tipo.value:<15}"
            f" {f.titolo[:35]}{sc_txt}")
    if verbose:
        if f.nome_cliente:
            riga += f"\n         Cliente:    {f.nome_cliente}"
        if f.rg_completo:
            riga += f"\n         RG:         {f.rg_completo}"
        if f.tribunale:
            riga += f"\n         Tribunale:  {f.tribunale}"
        if f.avvocato_referente:
            riga += f"\n         Avv.:       {f.avvocato_referente}"
        riga += f"\n         Docs: {f.documenti_count}  Attività: {f.attivita_count}"
    return riga


@cli.group("fascicoli")
def grp_fascicoli():
    """Gestione fascicoli (cartelle legali) dello studio."""
    pass


@grp_fascicoli.command("nuovo")
@click.option("--titolo", required=True, help="Titolo del fascicolo")
@click.option("--tipo", required=True,
              type=click.Choice([t.value for t in TipoFascicolo], case_sensitive=False),
              help="Tipo procedimento")
@click.option("--cliente", default="", help="ID cliente")
@click.option("--controparte", default="", help="Nome della controparte")
@click.option("--tribunale", default="", help="Tribunale competente")
@click.option("--rg", default="", help="Numero RG")
@click.option("--anno-rg", default=0, type=int, help="Anno RG")
@click.option("--avvocato", default="", help="Avvocato referente")
@click.option("--oggetto", default="", help="Oggetto della causa")
@click.option("--valore", default=0.0, type=float, help="Valore causa in euro")
@click.option("--note", default="", help="Note")
def cmd_fasc_nuovo(titolo, tipo, cliente, controparte, tribunale, rg,
                   anno_rg, avvocato, oggetto, valore, note):
    """Crea un nuovo fascicolo."""
    gf = _fascicoli()
    nome_cliente = ""
    if cliente:
        gc = _clienti()
        c = gc.get(cliente.upper())
        nome_cliente = c.nome_completo if c else ""
    try:
        f = gf.nuovo(
            titolo=titolo,
            tipo=TipoFascicolo(tipo.upper()),
            id_cliente=cliente.upper() if cliente else "",
            nome_cliente=nome_cliente,
            controparte=controparte,
            tribunale=tribunale,
            numero_rg=rg,
            anno_rg=anno_rg,
            avvocato_referente=avvocato,
            oggetto=oggetto,
            valore_causa=valore,
            note=note,
        )
        click.echo(f"Fascicolo creato: {f.numero} [{f.id}]")
        click.echo(_fmt_fasc(f, verbose=True))
    except ValueError as e:
        click.echo(f"Errore: {e}", err=True)
        sys.exit(1)


@grp_fascicoli.command("lista")
@click.option("--stato", type=click.Choice([s.value for s in StatoFascicolo],
              case_sensitive=False), default=None)
@click.option("--tipo", type=click.Choice([t.value for t in TipoFascicolo],
              case_sensitive=False), default=None)
@click.option("--archiviati", is_flag=True, default=False,
              help="Mostra solo archiviati")
@click.option("-v", "--verbose", is_flag=True, default=False)
def cmd_fasc_lista(stato, tipo, archiviati, verbose):
    """Elenca i fascicoli."""
    gf = _fascicoli()
    stato_e = StatoFascicolo(stato) if stato else None
    tipo_e = TipoFascicolo(tipo) if tipo else None
    fascicoli = gf.tutti(stato=stato_e, tipo=tipo_e, archiviati=archiviati)
    if not fascicoli:
        click.echo("Nessun fascicolo trovato.")
        return
    for f in fascicoli:
        click.echo(_fmt_fasc(f, verbose=verbose))


@grp_fascicoli.command("cerca")
@click.argument("testo")
@click.option("--archiviati", is_flag=True, default=False)
@click.option("-v", "--verbose", is_flag=True, default=False)
def cmd_fasc_cerca(testo, archiviati, verbose):
    """Cerca fascicoli per testo libero."""
    gf = _fascicoli()
    risultati = gf.cerca(testo=testo, archiviati=archiviati)
    if not risultati:
        click.echo("Nessun risultato.")
        return
    for f in risultati:
        click.echo(_fmt_fasc(f, verbose=verbose))


@grp_fascicoli.command("dettaglio")
@click.argument("id_fasc")
def cmd_fasc_dettaglio(id_fasc):
    """Mostra il dettaglio completo di un fascicolo."""
    gf = _fascicoli()
    f = gf.get(id_fasc.upper())
    if not f:
        click.echo(f"Fascicolo '{id_fasc}' non trovato.", err=True)
        sys.exit(1)
    click.echo(json.dumps(f.to_dict(), ensure_ascii=False, indent=2))


@grp_fascicoli.command("stato")
@click.argument("id_fasc")
@click.argument("nuovo_stato",
                type=click.Choice([s.value for s in StatoFascicolo], case_sensitive=False))
@click.option("--note", default="", help="Note sul cambio di stato")
@click.option("--avvocato", default="", help="Avvocato che esegue l'operazione")
def cmd_fasc_stato(id_fasc, nuovo_stato, note, avvocato):
    """Cambia lo stato di un fascicolo."""
    gf = _fascicoli()
    try:
        f = gf.cambia_stato(id_fasc.upper(), StatoFascicolo(nuovo_stato.upper()),
                            note=note, avvocato=avvocato)
        click.echo(f"Stato aggiornato: {f.stato.value}")
    except (KeyError, ValueError) as e:
        click.echo(str(e), err=True)
        sys.exit(1)


@grp_fascicoli.command("attivita")
@click.argument("id_fasc")
@click.option("--tipo", required=True,
              type=click.Choice([t.value for t in TipoAttivita], case_sensitive=False))
@click.option("--data", required=True, help="Data YYYY-MM-DD")
@click.option("--titolo", required=True, help="Titolo attività")
@click.option("--luogo", default="", help="Luogo")
@click.option("--avvocato", default="", help="Avvocato")
@click.option("--note", default="", help="Note")
def cmd_fasc_attivita(id_fasc, tipo, data, titolo, luogo, avvocato, note):
    """Aggiunge un'attività processuale a un fascicolo."""
    gf = _fascicoli()
    try:
        att = gf.aggiungi_attivita(
            id_fasc.upper(),
            tipo=TipoAttivita(tipo.upper()),
            data=data,
            titolo=titolo,
            luogo=luogo,
            avvocato=avvocato,
            note=note,
        )
        click.echo(f"Attività aggiunta: [{att.id}] {att.titolo} — {att.data}")
    except (KeyError, ValueError) as e:
        click.echo(str(e), err=True)
        sys.exit(1)


@grp_fascicoli.command("definisci")
@click.argument("id_fasc")
@click.option("--esito", default="", help="Esito finale della causa")
@click.option("--motivo", default="", help="Motivo della chiusura")
@click.option("--note", default="", help="Note")
@click.option("--avvocato", default="", help="Avvocato")
def cmd_fasc_definisci(id_fasc, esito, motivo, note, avvocato):
    """Marca un fascicolo come DEFINITO (pronto per archiviazione)."""
    gf = _fascicoli()
    try:
        f = gf.definisci(id_fasc.upper(), esito_finale=esito, motivo=motivo,
                         note=note, avvocato=avvocato)
        click.echo(f"Fascicolo {f.numero} definito. Esito: {esito or 'N/D'}")
    except (KeyError, ValueError) as e:
        click.echo(str(e), err=True)
        sys.exit(1)


@grp_fascicoli.command("archivia")
@click.argument("id_fasc")
@click.option("--avvocato", default="", help="Avvocato che archivia")
@click.option("--no-zip", is_flag=True, default=False, help="Non creare archivio ZIP")
def cmd_fasc_archivia(id_fasc, avvocato, no_zip):
    """Archivia definitivamente un fascicolo (crea ZIP dei documenti)."""
    gf = _fascicoli()
    try:
        f = gf.archivia(id_fasc.upper(), crea_zip=not no_zip, avvocato=avvocato)
        click.echo(f"Fascicolo {f.numero} archiviato.")
        if f.archivio and f.archivio.percorso_zip:
            click.echo(f"Archivio ZIP: {f.archivio.percorso_zip}")
    except (KeyError, ValueError) as e:
        click.echo(str(e), err=True)
        sys.exit(1)


@grp_fascicoli.command("scadenze")
@click.option("--giorni", default=7, show_default=True,
              help="Mostra scadenze entro N giorni")
def cmd_fasc_scadenze(giorni):
    """Mostra fascicoli con scadenze imminenti."""
    gf = _fascicoli()
    scadenze = gf.fascicoli_con_scadenze_imminenti(entro_giorni=giorni)
    if not scadenze:
        click.echo(f"Nessuna scadenza nei prossimi {giorni} giorni.")
        return
    for item in scadenze:
        f = item["fascicolo"]
        sc = item["scadenza"]
        click.echo(f"[{f.numero}] {f.titolo}")
        click.echo(f"         Scadenza: {sc.data} — {sc.titolo}")


@grp_fascicoli.command("statistiche")
def cmd_fasc_statistiche():
    """Mostra statistiche dei fascicoli."""
    gf = _fascicoli()
    stats = gf.statistiche()
    click.echo(f"Totale fascicoli:    {stats['totale']}")
    click.echo(f"Attivi:              {stats['attivi']}")
    click.echo(f"Definiti:            {stats['definiti']}")
    click.echo(f"Archiviati:          {stats['archiviati']}")
    click.echo(f"Totale documenti:    {stats['totale_documenti']}")
    click.echo(f"Totale attività:     {stats['totale_attivita']}")
    click.echo("\nPer tipo:")
    for t, n in stats["per_tipo"].items():
        if n:
            click.echo(f"  {t:<20} {n}")
    click.echo("\nPer stato:")
    for s, n in stats["per_stato"].items():
        if n:
            click.echo(f"  {s:<20} {n}")


# ============================================================ MESSAGGI

def _messaggi_config() -> ConfigMessaggistica:
    return ConfigMessaggistica(
        email=ConfigEmail(
            smtp_host=os.getenv("PCT_SMTP_HOST", ""),
            smtp_port=int(os.getenv("PCT_SMTP_PORT", "587")),
            username=os.getenv("PCT_SMTP_USER", ""),
            password=os.getenv("PCT_SMTP_PASS", ""),
            mittente_email=os.getenv("PCT_SMTP_FROM", ""),
            mittente_nome=os.getenv("PCT_STUDIO_NOME", "Studio Legale"),
        ),
        twilio=ConfigTwilio(
            account_sid=os.getenv("TWILIO_ACCOUNT_SID", ""),
            auth_token=os.getenv("TWILIO_AUTH_TOKEN", ""),
            numero_sms=os.getenv("TWILIO_SMS_NUMBER", ""),
            numero_whatsapp=os.getenv("TWILIO_WA_NUMBER", ""),
        ),
        studio_nome=os.getenv("PCT_STUDIO_NOME", "Studio Legale"),
    )


def _messaggi(db="./messaggi/storico.json") -> GestioneMessaggi:
    return GestioneMessaggi(config=_messaggi_config(), db_path=db)


@cli.group("messaggi")
def grp_messaggi():
    """Gestione messaggi (email/SMS/WhatsApp)."""
    pass


@grp_messaggi.command("lista")
@click.option("--canale", default="", help="EMAIL | SMS | WHATSAPP")
@click.option("--stato", default="", help="IN_CODA | INVIATO | CONSEGNATO | FALLITO …")
@click.option("--db", default="./messaggi/storico.json", help="DB messaggi")
def cmd_msg_lista(canale, stato, db):
    """Elenca messaggi nello storico."""
    gm = _messaggi(db)
    messaggi = gm.tutti(
        canale=CanaleMsggio(canale) if canale else None,
    )
    if stato:
        from .messaggi import StatoMessaggio
        messaggi = [m for m in messaggi if m.stato.value == stato]
    click.echo(f"{'ID':<12} {'CANALE':<10} {'STATO':<12} {'DATA':<20} DESTINATARIO")
    click.echo("-" * 72)
    for m in messaggi:
        dest = m.email_destinatario or m.telefono_destinatario or m.nome_destinatario
        click.echo(
            f"{m.id:<12} {m.canale.value:<10} {m.stato.value:<12} "
            f"{m.creato_il[:19]:<20} {dest}"
        )


@grp_messaggi.command("invia-email")
@click.option("--a", "dest", required=True, help="Indirizzo email destinatario")
@click.option("--oggetto", required=True, help="Oggetto email")
@click.option("--testo", required=True, help="Corpo testo")
@click.option("--id-cliente", default="", help="ID cliente (opzionale)")
@click.option("--db", default="./messaggi/storico.json", help="DB messaggi")
def cmd_msg_email(dest, oggetto, testo, id_cliente, db):
    """Invia un'email al destinatario."""
    gm = _messaggi(db)
    try:
        msg = gm.invia_email(
            destinatario=dest,
            oggetto=oggetto,
            corpo_testo=testo,
            id_cliente=id_cliente,
        )
        click.echo(f"Email {msg.stato.value}: {msg.id}")
    except Exception as e:
        click.echo(f"Errore: {e}", err=True)


@grp_messaggi.command("invia-sms")
@click.option("--a", "telefono", required=True, help="Numero E.164 (+39XXXXXXXXXX)")
@click.option("--testo", required=True, help="Testo SMS")
@click.option("--id-cliente", default="", help="ID cliente (opzionale)")
@click.option("--db", default="./messaggi/storico.json", help="DB messaggi")
def cmd_msg_sms(telefono, testo, id_cliente, db):
    """Invia un SMS tramite Twilio."""
    gm = _messaggi(db)
    try:
        msg = gm.invia_sms(telefono=telefono, testo=testo, id_cliente=id_cliente)
        click.echo(f"SMS {msg.stato.value}: {msg.id}")
    except Exception as e:
        click.echo(f"Errore: {e}", err=True)


@grp_messaggi.command("statistiche")
@click.option("--db", default="./messaggi/storico.json", help="DB messaggi")
def cmd_msg_statistiche(db):
    """Mostra statistiche messaggi."""
    stats = _messaggi(db).statistiche()
    click.echo(f"Totale:       {stats['totale']}")
    click.echo(f"Inviati:      {stats['inviati']}")
    click.echo(f"Consegnati:   {stats['consegnati']}")
    click.echo(f"Falliti:      {stats['falliti']}")
    click.echo(f"In coda:      {stats['in_coda']}")
    click.echo("\nPer canale:")
    for c, n in stats["per_canale"].items():
        click.echo(f"  {c:<12} {n}")


# ============================================================ BACKUP

def _backup(backup_dir="./backup") -> GestioneBackup:
    data_paths = {
        "agenda":    os.getenv("PCT_AGENDA_DB", "./agenda/appuntamenti.json"),
        "clienti":   os.getenv("PCT_CLIENTI_DB", "./clienti/anagrafica.json"),
        "fascicoli": os.getenv("PCT_FASCICOLI_DB", "./fascicoli/fascicoli.json"),
        "messaggi":  os.getenv("PCT_MESSAGGI_DB", "./messaggi/storico.json"),
        "documenti": os.getenv("PCT_FASCICOLI_DOCS", "./fascicoli/documenti"),
    }
    return GestioneBackup(directory_backup=backup_dir, percorsi_dati=data_paths)


@cli.group("backup")
def grp_backup():
    """Gestione backup e ripristino."""
    pass


@grp_backup.command("esegui")
@click.option("--tipo", default="COMPLETO", type=click.Choice(["COMPLETO", "INCREMENTALE"]),
              help="Tipo backup")
@click.option("--componenti", default="", help="Componenti separati da virgola (vuoto=tutti)")
@click.option("--nota", default="", help="Nota descrittiva")
@click.option("--dir", "backup_dir", default="./backup", help="Cartella backup")
def cmd_bk_esegui(tipo, componenti, nota, backup_dir):
    """Esegue un backup."""
    gb = _backup(backup_dir)
    comps = [c.strip() for c in componenti.split(",") if c.strip()] or None
    record = gb.esegui_backup(tipo=TipoBackup(tipo), componenti=comps, nota=nota)
    if record.stato == StatoBackup.OK:
        size_mb = round(record.dimensione_bytes / 1024 / 1024, 2)
        click.echo(f"Backup OK: {record.id}")
        click.echo(f"  File:    {record.percorso_file}")
        click.echo(f"  N°file:  {record.num_file}")
        click.echo(f"  Dim:     {size_mb} MB")
    else:
        click.echo(f"Backup FALLITO: {record.errore}", err=True)


@grp_backup.command("lista")
@click.option("--dir", "backup_dir", default="./backup", help="Cartella backup")
def cmd_bk_lista(backup_dir):
    """Elenca i backup disponibili."""
    gb = _backup(backup_dir)
    records = gb.tutti()
    if not records:
        click.echo("Nessun backup trovato.")
        return
    click.echo(f"{'ID':<38} {'TIPO':<12} {'STATO':<10} {'FILE':<6} {'DIM MB':<8} DATA")
    click.echo("-" * 90)
    for r in records:
        size_mb = round(r.dimensione_bytes / 1024 / 1024, 2)
        click.echo(
            f"{r.id:<38} {r.tipo.value:<12} {r.stato.value:<10} "
            f"{r.num_file:<6} {size_mb:<8} {r.timestamp[:19]}"
        )


@grp_backup.command("verifica")
@click.argument("id_backup")
@click.option("--dir", "backup_dir", default="./backup", help="Cartella backup")
def cmd_bk_verifica(id_backup, backup_dir):
    """Verifica l'integrità di un backup."""
    gb = _backup(backup_dir)
    ris = gb.verifica_integrita(id_backup)
    if ris["ok"]:
        click.echo(f"OK — backup integro: {id_backup}")
    else:
        click.echo(f"ATTENZIONE: backup corrotto! {id_backup}", err=True)
        click.echo(f"  Hash atteso:  {ris['hash_atteso']}")
        click.echo(f"  Hash attuale: {ris['hash_attuale']}")


@grp_backup.command("ripristina")
@click.argument("id_backup")
@click.option("--dest", required=True, help="Cartella di destinazione")
@click.option("--componenti", default="", help="Componenti separati da virgola (vuoto=tutti)")
@click.option("--sovrascrivi", is_flag=True, default=False, help="Sovrascrivi file esistenti")
@click.option("--password", default="", help="Password se backup cifrato")
@click.option("--dir", "backup_dir", default="./backup", help="Cartella backup")
def cmd_bk_ripristina(id_backup, dest, componenti, sovrascrivi, password, backup_dir):
    """Ripristina un backup nella destinazione specificata."""
    gb = _backup(backup_dir)
    comps = [c.strip() for c in componenti.split(",") if c.strip()] or None
    try:
        ris = gb.ripristina(
            id_backup, dest,
            componenti=comps,
            password=password,
            sovrascrivi=sovrascrivi,
        )
        click.echo(f"Ripristino completato:")
        click.echo(f"  Ripristinati: {ris['file_ripristinati']}")
        click.echo(f"  Saltati:      {ris['file_saltati']}")
        click.echo(f"  Errori:       {len(ris['errori'])}")
        click.echo(f"  Destinazione: {ris['destinazione']}")
    except Exception as e:
        click.echo(f"Errore: {e}", err=True)


@grp_backup.command("elimina")
@click.argument("id_backup")
@click.option("--dir", "backup_dir", default="./backup", help="Cartella backup")
def cmd_bk_elimina(id_backup, backup_dir):
    """Elimina un backup."""
    gb = _backup(backup_dir)
    try:
        gb.elimina(id_backup)
        click.echo(f"Backup {id_backup} eliminato.")
    except ValueError as e:
        click.echo(f"Errore: {e}", err=True)


@grp_backup.command("statistiche")
@click.option("--dir", "backup_dir", default="./backup", help="Cartella backup")
def cmd_bk_statistiche(backup_dir):
    """Mostra statistiche backup."""
    stats = _backup(backup_dir).statistiche()
    click.echo(f"Totale backup:   {stats['totale']}")
    click.echo(f"Completati:      {stats['ok']}")
    click.echo(f"Falliti:         {stats['falliti']}")
    click.echo(f"Corrotti:        {stats['corrotti']}")
    click.echo(f"Spazio totale:   {stats['dimensione_totale_mb']} MB")
    click.echo(f"Ultimo backup:   {stats['ultimo'] or 'mai'}")


# ============================================================ AUTH

def _utenti(db="./auth/utenti.json", audit="./auth/audit.json") -> GestioneUtenti:
    import secrets
    sk = os.getenv("PCT_SECRET_KEY", secrets.token_hex(32))
    return GestioneUtenti(db_path=db, audit_path=audit, secret_key=sk)


@cli.group("utenti")
def grp_utenti():
    """Gestione utenti e permessi."""
    pass


@grp_utenti.command("lista")
@click.option("--db", default="./auth/utenti.json")
def cmd_utenti_lista(db):
    """Elenca tutti gli utenti."""
    gu = _utenti(db)
    click.echo(f"{'USERNAME':<20} {'RUOLO':<16} {'STATO':<10} NOME")
    click.echo("-" * 70)
    for u in gu.tutti():
        stato = "Attivo" if u.attivo else "Disabilitato"
        click.echo(f"{u.username:<20} {u.ruolo.value:<16} {stato:<10} {u.nome_completo or '—'}")


@grp_utenti.command("crea")
@click.option("--username", required=True)
@click.option("--password", required=True)
@click.option("--ruolo", required=True,
              type=click.Choice([r.value for r in RuoloUtente]))
@click.option("--email", default="")
@click.option("--nome", default="")
@click.option("--db", default="./auth/utenti.json")
def cmd_utenti_crea(username, password, ruolo, email, nome, db):
    """Crea un nuovo utente."""
    gu = _utenti(db)
    try:
        u = gu.crea(username=username, password=password,
                    ruolo=RuoloUtente(ruolo), email=email, nome_completo=nome)
        click.echo(f"Utente creato: {u.username} ({u.ruolo.value})")
    except ValueError as e:
        click.echo(f"Errore: {e}", err=True)


@grp_utenti.command("cambia-password")
@click.argument("username")
@click.option("--password", required=True, prompt=True, hide_input=True,
              confirmation_prompt=True)
@click.option("--db", default="./auth/utenti.json")
def cmd_utenti_password(username, password, db):
    """Cambia la password di un utente."""
    gu = _utenti(db)
    u = gu.get_by_username(username)
    if not u:
        click.echo(f"Utente '{username}' non trovato.", err=True)
        return
    try:
        gu.cambia_password(u.id, password)
        click.echo(f"Password di '{username}' aggiornata.")
    except ValueError as e:
        click.echo(f"Errore: {e}", err=True)


@grp_utenti.command("audit")
@click.option("--username", default="", help="Filtra per username")
@click.option("--azione", default="", help="Filtra per azione")
@click.option("--db", default="./auth/utenti.json")
@click.option("--limit", default=30, show_default=True)
def cmd_utenti_audit(username, azione, db, limit):
    """Mostra il log di audit."""
    gu = _utenti(db)
    id_utente = ""
    if username:
        u = gu.get_by_username(username)
        if u:
            id_utente = u.id
    eventi = gu.audit_log(id_utente=id_utente, azione=azione, limit=limit)
    click.echo(f"{'DATA':<20} {'UTENTE':<15} {'AZIONE':<30} ESITO")
    click.echo("-" * 80)
    for e in eventi:
        click.echo(
            f"{e.timestamp[:19]:<20} {e.username:<15} {e.azione:<30} {e.esito}"
        )


# ============================================================ SCADENZIARIO

def _scadenziario(db="./scadenziario/scadenze.json") -> GestioneScadenziario:
    return GestioneScadenziario(db_path=db)


@cli.group("scadenze")
def grp_scadenze():
    """Gestione scadenziario legale."""
    pass


@grp_scadenze.command("lista")
@click.option("--tipo", default="", help="Tipo termine")
@click.option("--db", default="./scadenziario/scadenze.json")
def cmd_sc_lista(tipo, db):
    """Elenca le scadenze aperte."""
    gs = _scadenziario(db)
    scadenze = gs.tutte(tipo=TipoTermine(tipo) if tipo else None)
    click.echo(f"{'DATA':<12} {'PRIO':<9} {'GG':<5} {'TIPO':<22} TITOLO")
    click.echo("-" * 80)
    for s in scadenze:
        g = s.giorni_alla_scadenza
        g_str = f"{g}gg" if g is not None else "—"
        click.echo(
            f"{s.data_scadenza:<12} {s.priorita.value:<9} {g_str:<5} "
            f"{s.tipo.value[:21]:<22} {s.titolo}"
        )


@grp_scadenze.command("nuova")
@click.option("--titolo", required=True)
@click.option("--data", required=True, help="Data scadenza YYYY-MM-DD")
@click.option("--tipo", default="ALTRO",
              type=click.Choice([t.value for t in TipoTermine]))
@click.option("--perentorio", is_flag=True, default=False)
@click.option("--id-fascicolo", default="")
@click.option("--db", default="./scadenziario/scadenze.json")
def cmd_sc_nuova(titolo, data, tipo, perentorio, id_fascicolo, db):
    """Crea una nuova scadenza."""
    gs = _scadenziario(db)
    try:
        sc = gs.nuova(
            titolo=titolo,
            tipo=TipoTermine(tipo),
            data_scadenza=data,
            id_fascicolo=id_fascicolo,
            perentorio=perentorio,
        )
        click.echo(f"Scadenza creata: {sc.id}")
        click.echo(f"  Scadenza: {sc.data_scadenza} — {sc.titolo}")
    except ValueError as e:
        click.echo(f"Errore: {e}", err=True)


@grp_scadenze.command("preset")
@click.option("--titolo", required=True)
@click.option("--preset", required=True,
              type=click.Choice(list(PRESET_TERMINI.keys())))
@click.option("--decorrenza", required=True, help="Data decorrenza YYYY-MM-DD")
@click.option("--id-fascicolo", default="")
@click.option("--db", default="./scadenziario/scadenze.json")
def cmd_sc_preset(titolo, preset, decorrenza, id_fascicolo, db):
    """Crea una scadenza da preset processuale."""
    gs = _scadenziario(db)
    try:
        sc = gs.nuova_da_preset(
            preset_key=preset,
            titolo=titolo,
            data_decorrenza=decorrenza,
            id_fascicolo=id_fascicolo,
        )
        p = PRESET_TERMINI[preset]
        click.echo(f"Scadenza calcolata: {sc.data_scadenza} ({p['label']})")
        click.echo(f"  ID: {sc.id}")
    except ValueError as e:
        click.echo(f"Errore: {e}", err=True)


@grp_scadenze.command("completa")
@click.argument("id_sc")
@click.option("--note", default="")
@click.option("--db", default="./scadenziario/scadenze.json")
def cmd_sc_completa(id_sc, note, db):
    """Segna una scadenza come completata."""
    gs = _scadenziario(db)
    try:
        gs.completa(id_sc, note=note)
        click.echo(f"Scadenza {id_sc} completata.")
    except ValueError as e:
        click.echo(f"Errore: {e}", err=True)


@grp_scadenze.command("calcola")
@click.option("--da", "data_inizio", required=True, help="Data inizio YYYY-MM-DD")
@click.option("--giorni", required=True, type=int)
@click.option("--tipo", default="liberi", type=click.Choice(["liberi", "continui"]))
@click.option("--no-feriale", is_flag=True, default=False,
              help="Ignora sospensione feriale agostana")
def cmd_sc_calcola(data_inizio, giorni, tipo, no_feriale):
    """Calcola un termine processuale."""
    from datetime import date
    d = date.fromisoformat(data_inizio)
    scad = calcola_termine(d, giorni, tipo, sospensione_feriale=not no_feriale)
    g_rimasti = (scad - date.today()).days
    click.echo(f"Termine calcolato: {scad.isoformat()}")
    click.echo(f"  Da oggi: {g_rimasti} giorni")


@grp_scadenze.command("imminenti")
@click.option("--giorni", default=7, show_default=True)
@click.option("--db", default="./scadenziario/scadenze.json")
def cmd_sc_imminenti(giorni, db):
    """Mostra scadenze imminenti entro N giorni."""
    gs = _scadenziario(db)
    sc = gs.imminenti(entro_giorni=giorni)
    if not sc:
        click.echo(f"Nessuna scadenza entro {giorni} giorni.")
        return
    click.echo(f"Scadenze entro {giorni} giorni:")
    for s in sc:
        g = s.giorni_alla_scadenza
        pren = " [PERENTORIO]" if s.perentorio else ""
        click.echo(f"  {s.data_scadenza} ({g}gg) — {s.titolo}{pren}")


@grp_scadenze.command("statistiche")
@click.option("--db", default="./scadenziario/scadenze.json")
def cmd_sc_statistiche(db):
    """Mostra statistiche scadenziario."""
    stats = _scadenziario(db).statistiche()
    click.echo(f"Totale:          {stats['totale']}")
    click.echo(f"Aperte:          {stats['aperte']}")
    click.echo(f"Completate:      {stats['completate']}")
    click.echo(f"Scadute:         {stats['scadute']}")
    click.echo(f"Critiche:        {stats['critiche']}")
    click.echo(f"Alta priorità:   {stats['alte']}")
    click.echo(f"Entro 7 giorni:  {stats['imminenti_7gg']}")


# ============================================================ TARIFFARIO

from .tariffario import (
    calcola_compenso,
    tutte_le_materie,
    tutti_i_gradi,
    tutte_le_fasi,
    Materia,
    Grado,
    Fase,
)


@cli.group("tariffario")
def grp_tariffario():
    """Calcolo compensi secondo DM 55/2014."""
    pass


@grp_tariffario.command("materie")
def cmd_tar_materie():
    """Elenca le materie disponibili."""
    for m in tutte_le_materie():
        click.echo(f"  {m.value}")


@grp_tariffario.command("gradi")
def cmd_tar_gradi():
    """Elenca i gradi di giudizio disponibili."""
    for g in tutti_i_gradi():
        click.echo(f"  {g.value}")


@grp_tariffario.command("fasi")
def cmd_tar_fasi():
    """Elenca le fasi processuali disponibili."""
    for f in tutte_le_fasi():
        click.echo(f"  {f.value}")


@grp_tariffario.command("calcola")
@click.option("--materia", required=True,
              type=click.Choice([m.value for m in Materia]))
@click.option("--grado", required=True,
              type=click.Choice([g.value for g in Grado]))
@click.option("--valore", required=True, type=float,
              help="Valore della controversia in euro")
@click.option("--fasi", default="",
              help="Fasi da liquidare separate da virgola (es. STUDIO,INTRODUTTIVA)")
def cmd_tar_calcola(materia, grado, valore, fasi):
    """Calcola il compenso professionale (DM 55/2014)."""
    fasi_list = [Fase(f.strip()) for f in fasi.split(",") if f.strip()] if fasi else list(tutte_le_fasi())
    try:
        r = calcola_compenso(Materia(materia), Grado(grado), valore, fasi_list)
        click.echo(f"Materia:     {r.materia.value}")
        click.echo(f"Grado:       {r.grado.value}")
        click.echo(f"Valore:      € {r.valore_controversia:,.2f}")
        click.echo(f"Scaglione:   {r.scaglione.label}")
        click.echo("")
        click.echo(f"{'FASE':<22} {'MINIMO':>10} {'BASE':>10} {'MASSIMO':>10}")
        click.echo("-" * 56)
        for fase, sc in r.dettaglio.items():
            click.echo(
                f"{fase.value:<22} € {sc.minimo:>8,.2f} € {sc.base:>8,.2f} € {sc.massimo:>8,.2f}"
            )
        click.echo("-" * 56)
        click.echo(
            f"{'TOTALE':<22} € {r.totale_minimo:>8,.2f} € {r.totale_base:>8,.2f} € {r.totale_massimo:>8,.2f}"
        )
        if r.note:
            click.echo(f"\nNote: {r.note}")
    except (ValueError, KeyError) as e:
        click.echo(f"Errore: {e}", err=True)


# ============================================================ PARCELLE (FATTURAZIONE)

from .fatturazione import GestioneFatturazione, StatoParcella, MetodoPagamento


def _fatturazione(db="./fatturazione/parcelle.json") -> GestioneFatturazione:
    return GestioneFatturazione(db_path=db)


def _fmt_parcella(p, verbose: bool = False) -> str:
    line = (
        f"{p.id[:8]:<10} {p.numero:<8} {p.data_emissione:<12} "
        f"{p.stato.value:<10} € {p.totale:>10,.2f}"
    )
    if verbose:
        line += f"\n  Cliente: {p.id_cliente}  Fascicolo: {p.id_fascicolo or '—'}"
        line += f"\n  Scadenza: {p.data_scadenza or '—'}  Metodo: {(p.metodo_pagamento or {MetodoPagamento}).value if p.metodo_pagamento else '—'}"
    return line


@cli.group("parcelle")
def grp_parcelle():
    """Gestione parcelle e fatturazione."""
    pass


@grp_parcelle.command("lista")
@click.option("--stato", default="", help="Filtra per stato (BOZZA, EMESSA, PAGATA, ...)")
@click.option("--cliente", default="", help="Filtra per ID cliente")
@click.option("--verbose", "-v", is_flag=True)
@click.option("--db", default="./fatturazione/parcelle.json")
def cmd_par_lista(stato, cliente, verbose, db):
    """Elenca le parcelle."""
    gf = _fatturazione(db)
    parcelle = gf.per_cliente(cliente) if cliente else gf.tutte()
    if stato:
        try:
            s = StatoParcella(stato)
            parcelle = [p for p in parcelle if p.stato == s]
        except ValueError:
            click.echo(f"Stato non valido: {stato}", err=True)
            return
    click.echo(f"{'ID':<10} {'N.':<8} {'DATA':<12} {'STATO':<10} {'TOTALE':>12}")
    click.echo("-" * 56)
    for p in parcelle:
        click.echo(_fmt_parcella(p, verbose))
    click.echo(f"\nTotale: {len(parcelle)} parcella/e")


@grp_parcelle.command("nuova")
@click.option("--cliente", required=True, help="ID cliente")
@click.option("--fascicolo", default="", help="ID fascicolo (opzionale)")
@click.option("--voce", multiple=True,
              help="Voce: 'descrizione:qta:prezzo' (ripetibile)")
@click.option("--iva/--no-iva", default=True)
@click.option("--cassa/--no-cassa", default=True)
@click.option("--ritenuta/--no-ritenuta", default=False)
@click.option("--bollo/--no-bollo", default=False)
@click.option("--scadenza", default="", help="Data scadenza YYYY-MM-DD")
@click.option("--note", default="")
@click.option("--db", default="./fatturazione/parcelle.json")
def cmd_par_nuova(cliente, fascicolo, voce, iva, cassa, ritenuta, bollo, scadenza, note, db):
    """Crea una nuova parcella."""
    from .fatturazione import VoceParcella
    voci = []
    for v in voce:
        parti = v.split(":")
        if len(parti) < 3:
            click.echo(f"Formato voce non valido: '{v}' (usa descrizione:qta:prezzo)", err=True)
            return
        try:
            voci.append(VoceParcella(
                descrizione=parti[0],
                quantita=float(parti[1]),
                prezzo_unitario=float(parti[2]),
            ))
        except ValueError as e:
            click.echo(f"Errore nella voce '{v}': {e}", err=True)
            return
    if not voci:
        click.echo("Specificare almeno una voce con --voce 'descrizione:qta:prezzo'", err=True)
        return
    gf = _fatturazione(db)
    try:
        p = gf.crea(
            id_cliente=cliente,
            voci=voci,
            creato_da="cli",
            id_fascicolo=fascicolo or None,
            data_scadenza=scadenza or None,
            applica_iva=iva,
            applica_cassa=cassa,
            applica_ritenuta=ritenuta,
            applica_bollo=bollo,
            note=note,
        )
        click.echo(f"Parcella creata: {p.id}  (n. {p.numero})")
        click.echo(f"  Imponibile: € {p.imponibile:,.2f}")
        if p.applica_iva:
            click.echo(f"  IVA 22%:    € {p.iva:,.2f}")
        if p.applica_cassa:
            click.echo(f"  Cassa Forense 4%: € {p.cassa_forense:,.2f}")
        click.echo(f"  Totale:     € {p.totale:,.2f}")
    except Exception as e:
        click.echo(f"Errore: {e}", err=True)


@grp_parcelle.command("stato")
@click.argument("id_parcella")
@click.option("--nuovo-stato", required=True,
              type=click.Choice([s.value for s in StatoParcella]))
@click.option("--data-pagamento", default="", help="Data pagamento YYYY-MM-DD")
@click.option("--metodo", default="",
              type=click.Choice([m.value for m in MetodoPagamento] + [""]))
@click.option("--db", default="./fatturazione/parcelle.json")
def cmd_par_stato(id_parcella, nuovo_stato, data_pagamento, metodo, db):
    """Cambia lo stato di una parcella."""
    gf = _fatturazione(db)
    try:
        gf.cambia_stato(
            id_parcella,
            StatoParcella(nuovo_stato),
            data_pagamento=data_pagamento or None,
            metodo_pagamento=metodo or None,
        )
        click.echo(f"Parcella {id_parcella[:8]} → {nuovo_stato}")
    except ValueError as e:
        click.echo(f"Errore: {e}", err=True)


@grp_parcelle.command("statistiche")
@click.option("--anno", default=None, type=int)
@click.option("--db", default="./fatturazione/parcelle.json")
def cmd_par_statistiche(anno, db):
    """Mostra statistiche di fatturazione."""
    gf = _fatturazione(db)
    stats = gf.statistiche(anno=anno)
    titolo = f"Anno {anno}" if anno else "Tutti gli anni"
    click.echo(f"── Fatturazione — {titolo} ──")
    click.echo(f"Totale parcelle: {stats.get('totale', 0)}")
    click.echo(f"Bozze:           {stats.get('bozze', 0)}")
    click.echo(f"Emesse:          {stats.get('emesse', 0)}")
    click.echo(f"Pagate:          {stats.get('pagate', 0)}")
    click.echo(f"Scadute:         {stats.get('scadute', 0)}")
    click.echo(f"Fatturato tot.:  € {stats.get('fatturato_totale', 0):,.2f}")
    click.echo(f"Incassato:       € {stats.get('incassato', 0):,.2f}")
    click.echo(f"Da incassare:    € {stats.get('da_incassare', 0):,.2f}")


# ============================================================ TEMPLATE ATTI

from .template_atti import GestioneTemplateAtti, CATEGORIE


def _template_atti(db="./template_atti/templates.json") -> GestioneTemplateAtti:
    return GestioneTemplateAtti(db_path=db)


@cli.group("template-atti")
def grp_template_atti():
    """Gestione template per atti processuali."""
    pass


@grp_template_atti.command("lista")
@click.option("--categoria", default="", help="Filtra per categoria")
@click.option("--db", default="./template_atti/templates.json")
def cmd_ta_lista(categoria, db):
    """Elenca i template disponibili."""
    gt = _template_atti(db)
    templates = gt.tutti()
    if categoria:
        templates = [t for t in templates if t.categoria.lower() == categoria.lower()]
    click.echo(f"{'ID':<10} {'CATEGORIA':<20} {'BUILTIN':<8} TITOLO")
    click.echo("-" * 72)
    for t in templates:
        builtin = "✓" if t.builtin else " "
        click.echo(f"{t.id[:8]:<10} {t.categoria:<20} {builtin:<8} {t.titolo}")
    click.echo(f"\nTotale: {len(templates)} template")
    if not categoria:
        click.echo(f"Categorie: {', '.join(CATEGORIE)}")


@grp_template_atti.command("dettaglio")
@click.argument("id_template")
@click.option("--db", default="./template_atti/templates.json")
def cmd_ta_dettaglio(id_template, db):
    """Mostra il testo di un template."""
    gt = _template_atti(db)
    t = gt.get(id_template)
    if not t:
        click.echo(f"Template '{id_template}' non trovato.", err=True)
        return
    click.echo(f"Titolo:    {t.titolo}")
    click.echo(f"Categoria: {t.categoria}")
    click.echo(f"Builtin:   {'sì' if t.builtin else 'no'}")
    if t.note:
        click.echo(f"Note:      {t.note}")
    click.echo("\n── Corpo ──")
    click.echo(t.corpo)


@grp_template_atti.command("nuovo")
@click.option("--titolo", required=True)
@click.option("--categoria", required=True,
              type=click.Choice(CATEGORIE))
@click.option("--corpo", required=True, help="Testo del template (Jinja2). Usa @- per leggere da stdin.")
@click.option("--note", default="")
@click.option("--db", default="./template_atti/templates.json")
def cmd_ta_nuovo(titolo, categoria, corpo, note, db):
    """Crea un nuovo template atto."""
    if corpo == "@-":
        corpo = click.get_text_stream("stdin").read()
    gt = _template_atti(db)
    t = gt.crea(titolo=titolo, categoria=categoria, corpo=corpo, note=note)
    click.echo(f"Template creato: {t.id}")
    click.echo(f"  Titolo: {t.titolo}")


@grp_template_atti.command("elimina")
@click.argument("id_template")
@click.option("--db", default="./template_atti/templates.json")
def cmd_ta_elimina(id_template, db):
    """Elimina un template (solo personalizzati)."""
    gt = _template_atti(db)
    try:
        gt.elimina(id_template)
        click.echo(f"Template {id_template} eliminato.")
    except ValueError as e:
        click.echo(f"Errore: {e}", err=True)


@grp_template_atti.command("genera")
@click.argument("id_template")
@click.option("--var", multiple=True,
              help="Variabile: 'nome=valore' (ripetibile)")
@click.option("--output", "-o", default="", help="File di output (default: stdout)")
@click.option("--db", default="./template_atti/templates.json")
def cmd_ta_genera(id_template, var, output, db):
    """Renderizza un template con le variabili fornite."""
    gt = _template_atti(db)
    variabili = {}
    for v in var:
        if "=" not in v:
            click.echo(f"Formato non valido: '{v}' (usa nome=valore)", err=True)
            return
        k, _, val = v.partition("=")
        variabili[k.strip()] = val.strip()
    try:
        testo = gt.renderizza(id_template, variabili)
        if output:
            Path(output).write_text(testo, encoding="utf-8")
            click.echo(f"Template scritto in: {output}")
        else:
            click.echo(testo)
    except (ValueError, Exception) as e:
        click.echo(f"Errore: {e}", err=True)


# ============================================================ PRIVACY / GDPR

from .privacy import GestioneTrattamenti, TrattamentoDati


def _privacy(db="./privacy/registro.json") -> GestioneTrattamenti:
    return GestioneTrattamenti(db_path=db)


@cli.group("privacy")
def grp_privacy():
    """Registro dei trattamenti dati (GDPR art. 30)."""
    pass


@grp_privacy.command("lista")
@click.option("--tutti", is_flag=True, default=False,
              help="Mostra anche trattamenti disattivati")
@click.option("--db", default="./privacy/registro.json")
def cmd_priv_lista(tutti, db):
    """Elenca i trattamenti nel registro."""
    gt = _privacy(db)
    trattamenti = gt.tutti(solo_attivi=not tutti)
    click.echo(f"{'ID':<10} {'ATTIVO':<8} NOME")
    click.echo("-" * 60)
    for t in trattamenti:
        attivo = "✓" if t.attivo else "✗"
        click.echo(f"{t.id[:8]:<10} {attivo:<8} {t.nome}")
    click.echo(f"\nTotale: {len(trattamenti)}")


@grp_privacy.command("dettaglio")
@click.argument("id_trattamento")
@click.option("--db", default="./privacy/registro.json")
def cmd_priv_dettaglio(id_trattamento, db):
    """Mostra i dettagli di un trattamento."""
    gt = _privacy(db)
    t = gt.get(id_trattamento)
    if not t:
        click.echo(f"Trattamento '{id_trattamento}' non trovato.", err=True)
        return
    click.echo(f"Nome:                  {t.nome}")
    click.echo(f"Finalità:              {t.finalita}")
    click.echo(f"Categoria dati:        {t.categoria_dati}")
    click.echo(f"Base giuridica:        {t.base_giuridica}")
    click.echo(f"Soggetti interessati:  {t.soggetti_interessati}")
    click.echo(f"Destinatari:           {t.destinatari}")
    click.echo(f"Trasf. extra-UE:       {'sì' if t.trasferimento_extra_ue else 'no'}")
    if t.trasferimento_extra_ue:
        click.echo(f"Paese destinazione:    {t.paese_destinazione or '—'}")
    click.echo(f"Termine conservazione: {t.termine_conservazione}")
    click.echo(f"Misure sicurezza:      {t.misure_sicurezza}")
    click.echo(f"Responsabile:          {t.responsabile or '—'}")
    click.echo(f"Attivo:                {'sì' if t.attivo else 'no'}")
    if t.note:
        click.echo(f"Note:                  {t.note}")


@grp_privacy.command("nuovo")
@click.option("--nome", required=True)
@click.option("--finalita", required=True)
@click.option("--categoria-dati", required=True)
@click.option("--base-giuridica", required=True)
@click.option("--soggetti", required=True, help="Soggetti interessati")
@click.option("--destinatari", required=True)
@click.option("--conservazione", required=True, help="Termine di conservazione")
@click.option("--misure-sicurezza", required=True)
@click.option("--responsabile", default="")
@click.option("--extra-ue", is_flag=True, default=False,
              help="Trasferimento extra-UE")
@click.option("--paese", default="")
@click.option("--note", default="")
@click.option("--db", default="./privacy/registro.json")
def cmd_priv_nuovo(nome, finalita, categoria_dati, base_giuridica, soggetti,
                   destinatari, conservazione, misure_sicurezza, responsabile,
                   extra_ue, paese, note, db):
    """Aggiunge un trattamento al registro GDPR."""
    gt = _privacy(db)
    t = gt.nuovo(
        nome=nome,
        finalita=finalita,
        categoria_dati=categoria_dati,
        base_giuridica=base_giuridica,
        soggetti_interessati=soggetti,
        destinatari=destinatari,
        termine_conservazione=conservazione,
        misure_sicurezza=misure_sicurezza,
        responsabile=responsabile or None,
        trasferimento_extra_ue=extra_ue,
        paese_destinazione=paese or None,
        note=note or None,
    )
    click.echo(f"Trattamento creato: {t.id}")
    click.echo(f"  Nome: {t.nome}")


@grp_privacy.command("elimina")
@click.argument("id_trattamento")
@click.option("--db", default="./privacy/registro.json")
def cmd_priv_elimina(id_trattamento, db):
    """Rimuove un trattamento dal registro."""
    gt = _privacy(db)
    try:
        gt.elimina(id_trattamento)
        click.echo(f"Trattamento {id_trattamento} eliminato.")
    except ValueError as e:
        click.echo(f"Errore: {e}", err=True)


# ============================================================ OCR

from .ocr import estrai_testo


@cli.command("ocr")
@click.argument("file", type=click.Path(exists=True))
@click.option("--output", "-o", default="",
              help="File di output (default: stdout)")
def cmd_ocr(file, output):
    """Estrae testo da un PDF o immagine tramite OCR."""
    try:
        testo = estrai_testo(file)
        if output:
            Path(output).write_text(testo, encoding="utf-8")
            click.echo(f"Testo estratto in: {output}")
        else:
            click.echo(testo)
    except Exception as e:
        click.echo(f"Errore OCR: {e}", err=True)


# ============================================================ REPORT PDF

from .reports import fascicolo_pdf, scadenze_pdf


@cli.group("report")
def grp_report():
    """Generazione report PDF."""
    pass


@grp_report.command("fascicolo")
@click.argument("id_fasc")
@click.option("--output", "-o", required=True, help="File PDF di output")
@click.option("--studio", default="Studio Legale", help="Nome dello studio")
@click.option("--db-fasc", default="./fascicoli/fascicoli.json")
def cmd_rep_fascicolo(id_fasc, output, studio, db_fasc):
    """Genera il report PDF di un fascicolo."""
    gf_mod = _fascicoli(db_fasc)
    f = gf_mod.get(id_fasc)
    if not f:
        click.echo(f"Fascicolo '{id_fasc}' non trovato.", err=True)
        return
    try:
        percorso = fascicolo_pdf(f.to_dict(), output, studio_nome=studio)
        click.echo(f"Report generato: {percorso}")
    except Exception as e:
        click.echo(f"Errore generazione PDF: {e}", err=True)


@grp_report.command("scadenze")
@click.option("--output", "-o", required=True, help="File PDF di output")
@click.option("--studio", default="Studio Legale", help="Nome dello studio")
@click.option("--titolo", default="Scadenziario")
@click.option("--giorni", default=0, type=int,
              help="Solo scadenze entro N giorni (0 = tutte)")
@click.option("--db", default="./scadenziario/scadenze.json")
def cmd_rep_scadenze(output, studio, titolo, giorni, db):
    """Genera il report PDF dello scadenziario."""
    gs = _scadenziario(db)
    if giorni:
        scadenze = gs.imminenti(entro_giorni=giorni)
    else:
        scadenze = gs.tutte()
    try:
        percorso = scadenze_pdf(
            [s.to_dict() if hasattr(s, "to_dict") else s for s in scadenze],
            output,
            titolo=titolo,
            studio_nome=studio,
        )
        click.echo(f"Report generato: {percorso}")
    except Exception as e:
        click.echo(f"Errore generazione PDF: {e}", err=True)


# ============================================================ PORTALE CLIENTI

from .portale import GestionePortale


def _portale(db="./portale/portali.json") -> GestionePortale:
    return GestionePortale(db_path=db)


@cli.group("portale")
def grp_portale():
    """Gestione portale clienti."""
    pass


@grp_portale.command("stato")
@click.argument("id_cliente")
@click.option("--db", default="./portale/portali.json")
def cmd_portale_stato(id_cliente, db):
    """Mostra lo stato del portale per un cliente."""
    gp = _portale(db)
    p = gp.get_by_cliente(id_cliente)
    if not p:
        click.echo(f"Nessun portale attivato per il cliente '{id_cliente}'.")
        return
    click.echo(f"ID portale:     {p.id}")
    click.echo(f"Attivo:         {'sì' if p.is_attivo else 'no'}")
    click.echo(f"Creato il:      {p.creato_il[:10]}")
    click.echo(f"Scade il:       {p.scade_il or 'mai'}")
    click.echo(f"Accessi:        {p.n_accessi}")
    click.echo(f"Ultimo accesso: {(p.ultimo_accesso or '—')[:19]}")
    click.echo(f"Privacy firmata: {'sì' if p.privacy_firmata else 'no'}")


@grp_portale.command("attiva")
@click.argument("id_cliente")
@click.option("--scadenza", default="", help="Data scadenza YYYY-MM-DD (opzionale)")
@click.option("--db", default="./portale/portali.json")
def cmd_portale_attiva(id_cliente, scadenza, db):
    """Attiva il portale per un cliente e stampa il token di accesso."""
    gp = _portale(db)
    from .portale import PermessiPortale
    token, p = gp.crea(
        id_cliente=id_cliente,
        creato_da="cli",
        permessi=PermessiPortale(),
        scade_il=scadenza or None,
    )
    click.echo(f"Portale attivato: {p.id}")
    click.echo(f"  Token di accesso: {token}")
    click.echo(f"  Scade il: {p.scade_il or 'mai'}")
    click.echo("\nATTENZIONE: conservare il token in modo sicuro — non verrà mostrato di nuovo.")


@grp_portale.command("revoca")
@click.argument("id_cliente")
@click.option("--db", default="./portale/portali.json")
def cmd_portale_revoca(id_cliente, db):
    """Revoca l'accesso al portale per un cliente."""
    gp = _portale(db)
    p = gp.get_by_cliente(id_cliente)
    if not p:
        click.echo(f"Nessun portale trovato per '{id_cliente}'.", err=True)
        return
    try:
        gp.revoca(p.id)
        click.echo(f"Portale {p.id} revocato.")
    except ValueError as e:
        click.echo(f"Errore: {e}", err=True)


# ============================================================ NOTIFICHE WHATSAPP

from .notifiche_wa import (
    ConfigWA,
    wa_link,
    invia_messaggio,
    msg_libero,
    msg_promemoria_appuntamento,
    msg_nuova_parcella,
    msg_scadenza_imminente,
    msg_link_portale,
)


@cli.group("notifiche-wa")
def grp_notifiche_wa():
    """Invio messaggi WhatsApp ai clienti."""
    pass


@grp_notifiche_wa.command("link")
@click.argument("numero")
@click.argument("messaggio")
def cmd_wa_link(numero, messaggio):
    """Genera un link wa.me (apre WhatsApp senza configurazione API)."""
    url = wa_link(numero, messaggio)
    click.echo(url)


@grp_notifiche_wa.command("invia")
@click.argument("numero")
@click.argument("messaggio")
@click.option("--studio", default="Studio Legale", help="Nome studio (per template)")
def cmd_wa_invia(numero, messaggio, studio):
    """Invia un messaggio WhatsApp tramite Twilio o CallMeBot (da env)."""
    cfg = ConfigWA.da_env()
    if not cfg.ha_twilio and not cfg.ha_callmebot:
        click.echo(
            "Nessun provider configurato. Imposta le variabili d'ambiente:\n"
            "  Twilio:     PCT_TWILIO_SID, PCT_TWILIO_TOKEN, PCT_TWILIO_NUMERO\n"
            "  CallMeBot:  PCT_CALLMEBOT_KEY",
            err=True,
        )
        return
    try:
        result = invia_messaggio(numero, messaggio, cfg)
        click.echo(f"Messaggio inviato. Risposta: {result.get('status', result)}")
    except Exception as e:
        click.echo(f"Errore invio: {e}", err=True)


@grp_notifiche_wa.command("template")
@click.option("--tipo", required=True,
              type=click.Choice(["appuntamento", "parcella", "scadenza", "portale", "libero"]))
@click.option("--nome-cliente", required=True)
@click.option("--studio", default="Studio Legale")
@click.option("--titolo", default="")
@click.option("--data-ora", default="")
@click.option("--luogo", default="")
@click.option("--numero-parcella", default="")
@click.option("--totale", default=0.0, type=float)
@click.option("--scadenza", default="")
@click.option("--fascicolo", default="")
@click.option("--perentorio", is_flag=True, default=False)
@click.option("--link", default="")
@click.option("--testo-libero", default="")
def cmd_wa_template(tipo, nome_cliente, studio, titolo, data_ora, luogo,
                    numero_parcella, totale, scadenza, fascicolo, perentorio, link, testo_libero):
    """Genera il testo di un messaggio WhatsApp da template."""
    if tipo == "appuntamento":
        msg = msg_promemoria_appuntamento(nome_cliente, titolo, data_ora, luogo, studio)
    elif tipo == "parcella":
        msg = msg_nuova_parcella(nome_cliente, numero_parcella, totale, scadenza, studio)
    elif tipo == "scadenza":
        msg = msg_scadenza_imminente(nome_cliente, titolo, scadenza, fascicolo, perentorio)
    elif tipo == "portale":
        msg = msg_link_portale(nome_cliente, link, studio)
    else:
        msg = msg_libero(nome_cliente, testo_libero, studio)
    click.echo(msg)


# ============================================================ PAGAMENTI

from .pagamenti import GestionePagamenti, StatoPagamento


def _pagamenti(db_dir="./pagamenti") -> GestionePagamenti:
    return GestionePagamenti(db_dir=db_dir)


@cli.group("pagamenti")
def grp_pagamenti():
    """Gestione link di pagamento digitale."""
    pass


@grp_pagamenti.command("config")
@click.option("--dir", "db_dir", default="./pagamenti")
def cmd_pag_config(db_dir):
    """Mostra i provider di pagamento configurati."""
    gp = _pagamenti(db_dir)
    cfg = gp.config
    attivi = cfg.provider_attivi()
    click.echo(f"Provider attivi: {', '.join(attivi) if attivi else '(nessuno)'}")
    click.echo(f"  Stripe:   {'abilitato' if cfg.stripe.abilitato else 'disabilitato'}")
    click.echo(f"  PayPal:   {'abilitato' if cfg.paypal.abilitato else 'disabilitato'}")
    click.echo(f"  Satispay: {'abilitato' if cfg.satispay.abilitato else 'disabilitato'}")
    click.echo(f"  SumUp:    {'abilitato' if cfg.sumup.abilitato else 'disabilitato'}")
    click.echo(f"  Bonifico: {'abilitato' if cfg.bonifico.abilitato else 'disabilitato'}")
    if cfg.bonifico.abilitato:
        click.echo(f"    IBAN: {cfg.bonifico.iban}")


@grp_pagamenti.command("lista")
@click.option("--stato", default="",
              type=click.Choice([s.value for s in StatoPagamento] + [""]))
@click.option("--dir", "db_dir", default="./pagamenti")
def cmd_pag_lista(stato, db_dir):
    """Elenca i link di pagamento."""
    gp = _pagamenti(db_dir)
    links = gp.tutti_link()
    if stato:
        links = [lp for lp in links if lp.stato.value == stato]
    click.echo(f"{'ID':<10} {'PARCELLA':<10} {'IMPORTO':>10} {'STATO':<10} {'SCADE':<12} PROVIDER")
    click.echo("-" * 72)
    for lp in links:
        click.echo(
            f"{lp.id[:8]:<10} {lp.id_parcella[:8]:<10} "
            f"€ {lp.importo:>8,.2f} {lp.stato.value:<10} "
            f"{(lp.scade_il or '—')[:10]:<12} {lp.provider_usato or '—'}"
        )
    click.echo(f"\nTotale: {len(links)}")


@grp_pagamenti.command("nuovo-link")
@click.option("--parcella", required=True, help="ID parcella")
@click.option("--cliente", required=True, help="ID cliente")
@click.option("--importo", required=True, type=float, help="Importo in euro")
@click.option("--descrizione", default="Pagamento parcella")
@click.option("--giorni-validita", default=30, show_default=True)
@click.option("--dir", "db_dir", default="./pagamenti")
def cmd_pag_nuovo_link(parcella, cliente, importo, descrizione, giorni_validita, db_dir):
    """Crea un link di pagamento per una parcella."""
    gp = _pagamenti(db_dir)
    try:
        lp = gp.crea_link(
            id_parcella=parcella,
            id_cliente=cliente,
            importo=importo,
            descrizione=descrizione,
            giorni_validita=giorni_validita,
        )
        click.echo(f"Link creato: {lp.id}")
        click.echo(f"  Token:    {lp.token}")
        click.echo(f"  Importo:  € {lp.importo:,.2f}")
        click.echo(f"  Scade il: {lp.scade_il or '—'}")
    except Exception as e:
        click.echo(f"Errore: {e}", err=True)


# ============================================================ IMPOSTAZIONI STUDIO

from .config_studio import (
    GestioneConfigStudio,
    ConfigPEC as _ConfigPEC,
    ConfigSMTP as _ConfigSMTP,
    test_pec_smtp,
    test_pec_imap,
    test_smtp_email,
)


def _cfg_studio(config_path="./config/studio.json") -> GestioneConfigStudio:
    return GestioneConfigStudio(config_path=config_path)


@cli.group("impostazioni")
def grp_impostazioni():
    """Configurazione dello studio (PEC, SMTP, firma, WhatsApp, scheduler)."""
    pass


@grp_impostazioni.command("mostra")
@click.option("--config", default="./config/studio.json")
def cmd_imp_mostra(config):
    """Mostra la configurazione corrente dello studio."""
    gs = _cfg_studio(config)
    c = gs.config
    s = c.studio
    click.echo(f"── Dati Studio ──────────────────────────────")
    click.echo(f"  Nome:       {s.nome or '—'}")
    click.echo(f"  Avvocato:   {s.avvocato or '—'}")
    click.echo(f"  P.IVA:      {s.piva or '—'}")
    click.echo(f"  C.F.:       {s.cf or '—'}")
    click.echo(f"  Indirizzo:  {s.indirizzo or '—'}")
    click.echo(f"  IBAN:       {s.iban or '—'}")
    click.echo(f"\n── PEC ──────────────────────────────────────")
    click.echo(f"  Indirizzo:  {c.pec.indirizzo or '—'}")
    click.echo(f"  SMTP:       {c.pec.smtp_host}:{c.pec.smtp_port}  SSL={'sì' if c.pec.use_ssl else 'no'}")
    click.echo(f"  IMAP:       {c.pec.imap_host}:{c.pec.imap_port}")
    click.echo(f"  Password:   {'configurata' if c.pec.password else 'non impostata'}")
    click.echo(f"\n── Firma Digitale ───────────────────────────")
    click.echo(f"  P12 path:   {c.firma.p12_path or '—'}")
    click.echo(f"  CF avvocato:{c.firma.cf_avvocato or '—'}")
    click.echo(f"  Password:   {'configurata' if c.firma.password else 'non impostata'}")
    click.echo(f"\n── SMTP Email ───────────────────────────────")
    click.echo(f"  Host:       {c.smtp.host or '—'}:{c.smtp.port}")
    click.echo(f"  Username:   {c.smtp.username or '—'}")
    click.echo(f"  From:       {c.smtp.from_address or '—'}")
    click.echo(f"  TLS:        {'sì' if c.smtp.use_tls else 'no'}")
    click.echo(f"\n── WhatsApp ─────────────────────────────────")
    click.echo(f"  Twilio SID: {c.whatsapp.twilio_sid or '—'}")
    click.echo(f"  Twilio num: {c.whatsapp.twilio_numero or '—'}")
    click.echo(f"  CallMeBot:  {'configurato' if c.whatsapp.callmebot_key else '—'}")
    click.echo(f"\n── Scheduler ────────────────────────────────")
    click.echo(f"  Backup:     {c.scheduler.backup_ora}  ({'abilitato' if c.scheduler.backup_abilitato else 'disabilitato'})")
    click.echo(f"  WA remind:  {c.scheduler.wa_reminder_ora}  ({'abilitato' if c.scheduler.wa_reminder_abilitato else 'disabilitato'})")


@grp_impostazioni.command("pec")
@click.option("--indirizzo", required=True, help="Indirizzo PEC (es. studio@pec.aruba.it)")
@click.option("--password", prompt=True, hide_input=True, confirmation_prompt=True,
              help="Password casella PEC")
@click.option("--smtp-host", default="smtp.pec.aruba.it", show_default=True)
@click.option("--smtp-port", default=465, show_default=True, type=int)
@click.option("--imap-host", default="imaps.pec.aruba.it", show_default=True)
@click.option("--imap-port", default=993, show_default=True, type=int)
@click.option("--no-ssl", is_flag=True, default=False)
@click.option("--config", default="./config/studio.json")
def cmd_imp_pec(indirizzo, password, smtp_host, smtp_port, imap_host, imap_port, no_ssl, config):
    """Configura l'account PEC dello studio."""
    from .config_studio import ConfigPEC
    gs = _cfg_studio(config)
    cfg = gs.config
    cfg.pec = ConfigPEC(
        indirizzo=indirizzo,
        password=password,
        smtp_host=smtp_host,
        smtp_port=smtp_port,
        imap_host=imap_host,
        imap_port=imap_port,
        use_ssl=not no_ssl,
    )
    gs.aggiorna(cfg)
    click.echo(f"PEC configurata: {indirizzo}  (salvata in {config})")


@grp_impostazioni.command("test-pec")
@click.option("--config", default="./config/studio.json")
def cmd_imp_test_pec(config):
    """Testa la connessione PEC (SMTP + IMAP)."""
    gs = _cfg_studio(config)
    c = gs.config.pec
    if not c.indirizzo:
        click.echo("PEC non configurata. Usa: pct impostazioni pec --indirizzo ...", err=True)
        return
    click.echo(f"Test SMTP ({c.smtp_host}:{c.smtp_port})...", nl=False)
    r = test_pec_smtp(c)
    click.echo(f"  {'✓ OK' if r['ok'] else '✗ ERRORE'}  {r['messaggio']}")
    click.echo(f"Test IMAP ({c.imap_host}:{c.imap_port})...", nl=False)
    r = test_pec_imap(c)
    click.echo(f"  {'✓ OK' if r['ok'] else '✗ ERRORE'}  {r['messaggio']}")


@grp_impostazioni.command("smtp")
@click.option("--host", required=True)
@click.option("--port", default=587, type=int, show_default=True)
@click.option("--username", required=True)
@click.option("--password", prompt=True, hide_input=True, confirmation_prompt=True)
@click.option("--from-address", default="")
@click.option("--from-name", default="")
@click.option("--no-tls", is_flag=True, default=False)
@click.option("--config", default="./config/studio.json")
def cmd_imp_smtp(host, port, username, password, from_address, from_name, no_tls, config):
    """Configura il server SMTP per le email dello studio."""
    from .config_studio import ConfigSMTP
    gs = _cfg_studio(config)
    cfg = gs.config
    cfg.smtp = ConfigSMTP(
        host=host, port=port,
        username=username, password=password,
        from_address=from_address or username,
        from_name=from_name,
        use_tls=not no_tls,
    )
    gs.aggiorna(cfg)
    click.echo(f"SMTP configurato: {username}@{host}:{port}")


@grp_impostazioni.command("test-smtp")
@click.option("--config", default="./config/studio.json")
def cmd_imp_test_smtp(config):
    """Testa la connessione SMTP email."""
    gs = _cfg_studio(config)
    c = gs.config.smtp
    if not c.host:
        click.echo("SMTP non configurato.", err=True)
        return
    click.echo(f"Test SMTP ({c.host}:{c.port})...", nl=False)
    r = test_smtp_email(c)
    click.echo(f"  {'✓ OK' if r['ok'] else '✗ ERRORE'}  {r['messaggio']}")


@grp_impostazioni.command("studio")
@click.option("--nome", default="")
@click.option("--avvocato", default="")
@click.option("--piva", default="")
@click.option("--cf", default="")
@click.option("--indirizzo", default="")
@click.option("--iban", default="")
@click.option("--config", default="./config/studio.json")
def cmd_imp_studio(nome, avvocato, piva, cf, indirizzo, iban, config):
    """Imposta i dati anagrafici dello studio."""
    gs = _cfg_studio(config)
    cfg = gs.config
    if nome:        cfg.studio.nome = nome
    if avvocato:    cfg.studio.avvocato = avvocato
    if piva:        cfg.studio.piva = piva
    if cf:          cfg.studio.cf = cf
    if indirizzo:   cfg.studio.indirizzo = indirizzo
    if iban:        cfg.studio.iban = iban
    gs.aggiorna(cfg)
    click.echo(f"Dati studio aggiornati e salvati in {config}")


def main():
    cli()


if __name__ == "__main__":
    main()
