"""Estrae, pseudonimizzati, gli atti redatti dallo studio, per lo stile della redazione guidata e l'addestramento di Lex.

Uso sul server (una volta, sola lettura dei dati dello studio):
    docker compose ... exec -T app python -m lex.dataset.atti_studio --out /data/export/atti_studio_anonimi.jsonl

Criteri, senza rileggere alcun documento (CLAUDE.md «Registro delle letture»):
- solo documenti caricati dallo studio (``fonte_documento`` CARICAMENTO_STUDIO, non eliminati) che sono atti di parte
  (citazione, ricorso, comparsa, memoria, atto giudiziario) oppure fanno parte di un deposito PCT dello studio;
- il testo è quello già estratto e indicizzato (indice di ricerca o cache OCR); senza testo l'atto è saltato.
Il file prodotto contiene solo testo pseudonimizzato (``lex.dataset.anonimizza_atti``) e categorie: nessun id di
fascicolo, cliente o documento, nessuna data esatta. Un riepilogo indica quanti atti, di che tipo e i residui da
controllare. Base: art. 89 Reg. UE 2016/679 (garanzie per finalità di ricerca e trattamento ulteriore), titolare lo
studio, che ha autorizzato l'uso interno per l'addestramento di Lex il 21/10/2026.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sqlite3
from collections import Counter
from collections.abc import Iterable
from pathlib import Path
from typing import Any

from lex.dataset.anonimizza_atti import Pseudonimizzatore, residui

TIPI_ATTO = {"ATTO_GIUDIZIARIO", "MEMORIA", "RICORSO", "CITAZIONE", "COMPARSA"}
CAMPI_PERSONA = ("controparte", "avvocato_controparte", "avvocato_referente", "avvocato_dominus", "giudice", "cliente_nome",
                 "nome_cliente", "parte_assistita", "ctu", "ctp")
CAMPI_CODICE = ("cf_controparte", "cf_cliente", "piva_controparte")


def _valore(oggetto: Any, nome: str) -> str:
    v = getattr(oggetto, nome, "") if not isinstance(oggetto, dict) else oggetto.get(nome, "")
    return str(getattr(v, "value", v) or "").strip()


def entita_fascicolo(fascicolo: Any, cliente: Any = None, studio: Any = None) -> list[tuple[str, str]]:
    """Persone e codici noti del fascicolo, del cliente e dello studio da sostituire per primi."""
    out = [("PERSONA", _valore(fascicolo, c)) for c in CAMPI_PERSONA]
    out += [("CODICE_FISCALE", _valore(fascicolo, c)) for c in CAMPI_CODICE]
    for parte in getattr(fascicolo, "parti", None) or []:
        for c in ("nome", "denominazione", "ragione_sociale", "nominativo"):
            out.append(("PERSONA", _valore(parte, c)))
        out.append(("CODICE_FISCALE", _valore(parte, "codice_fiscale") or _valore(parte, "cf")))
    if cliente is not None:
        nome = " ".join(x for x in (_valore(cliente, "nome"), _valore(cliente, "cognome")) if x)
        out += [("PERSONA", nome), ("PERSONA", _valore(cliente, "ragione_sociale")), ("PERSONA", _valore(cliente, "denominazione")),
                ("CODICE_FISCALE", _valore(cliente, "codice_fiscale")), ("INDIRIZZO", _valore(cliente, "indirizzo"))]
    if studio is not None:
        out += [("PERSONA", _valore(studio, "avvocato_ref")), ("STUDIO", _valore(studio, "nome")), ("INDIRIZZO", _valore(studio, "indirizzo")),
                ("CODICE_FISCALE", _valore(studio, "cf"))]
    return [(c, v) for c, v in out if v]


def ids_depositati(fascicolo: Any) -> set[str]:
    ids: set[str] = set()
    for dep in getattr(fascicolo, "depositi_pct", None) or []:
        if _valore(dep, "fonte_portale"):
            continue
        ids |= {str(x) for x in (getattr(dep, "documenti_ids", None) or (dep.get("documenti_ids") if isinstance(dep, dict) else []) or [])}
    return ids


def atti_dello_studio(fascicolo: Any) -> Iterable[Any]:
    depositati = ids_depositati(fascicolo)
    for doc in getattr(fascicolo, "documenti", None) or []:
        if getattr(doc, "eliminato_il", None):
            continue
        fonte = _valore(doc, "fonte_documento") or "CARICAMENTO_STUDIO"
        if fonte != "CARICAMENTO_STUDIO" or _valore(doc, "mittente_portale"):
            continue
        tipo = _valore(doc, "tipo").upper()
        if tipo in TIPI_ATTO or str(getattr(doc, "id", "")) in depositati or _valore(doc, "id_deposito_pct"):
            yield doc


def testo_indicizzato(indice: Path, id_fasc: str, doc: Any) -> str:
    """Testo già estratto: indice di ricerca o cache OCR (nessuna nuova lettura del file)."""
    if not indice.exists():
        return ""
    c = sqlite3.connect(f"file:{indice}?mode=ro", uri=True)
    try:
        riga = c.execute("SELECT corpo FROM documenti WHERE tipo='documento' AND entity_id=?", (f"{id_fasc}:{getattr(doc, 'id', '')}",)).fetchone()
        if riga and riga[0]:
            return riga[0]
        impronta = _valore(doc, "hash_sha256")
        if impronta:
            riga = c.execute("SELECT testo FROM ocr_cache WHERE hash_sha256=?", (impronta,)).fetchone()
            if riga and riga[0]:
                return riga[0]
    except sqlite3.Error:
        return ""
    finally:
        c.close()
    return ""


def record(fascicolo: Any, doc: Any, testo: str, entita: list[tuple[str, str]], sale: str) -> dict[str, Any]:
    p = Pseudonimizzatore()
    anonimo = p.anonimizza(testo, entita)
    return {"id": hashlib.sha256(f"{sale}:{getattr(fascicolo, 'id', '')}:{getattr(doc, 'id', '')}".encode()).hexdigest()[:16],
            "tipo_documento": _valore(doc, "tipo"), "materia": _valore(fascicolo, "tipo") or _valore(fascicolo, "materia"),
            "anno": (_valore(doc, "data_caricamento") or _valore(doc, "creato_il"))[:4], "caratteri": len(anonimo),
            "sostituzioni": p.conteggi, "residui": residui(anonimo)[:40], "testo": anonimo}


def _contesti(app) -> list[tuple[str, dict[str, Any], Any]]:
    if not app.config.get("MULTI_TENANT"):
        return [("", {}, None)]
    from pct.tenant import GestioneTenant, StatoTenant
    manager = GestioneTenant(registry_path=app.config["TENANTS_REGISTRY"])
    return [(s.slug, dict(manager.percorsi_dati(s.slug, reconcile_aliases=False)), s) for s in manager.lista() if s.stato != StatoTenant.SOSPESO]


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--out", required=True)
    ap.add_argument("--limite", type=int, default=0, help="numero massimo di atti (0 = tutti)")
    a = ap.parse_args(argv)
    from flask import g

    from web.app import create_app
    app = create_app()
    sale = hashlib.sha256(Path(a.out).name.encode() + str(Path(a.out).stat().st_mtime if Path(a.out).exists() else 0).encode()).hexdigest()
    righe, tipi, saltati = [], Counter(), Counter()
    for slug, paths, studio in _contesti(app):
        with app.test_request_context("/__estrazione-atti-studio"):
            g.data_paths, g.tenant, g.tenant_context_slug = paths, studio, slug
            g.tenant_context_required, g.tenant_context_missing, g.storage_runtime = False, False, None
            from web.helpers import get_clienti, get_fascicoli
            indice = Path(paths.get("SEARCH_INDEX") or app.config["SEARCH_INDEX"])
            clienti = get_clienti()
            for fascicolo in get_fascicoli().tutti(archiviati=True) if _accetta_archiviati() else get_fascicoli().tutti():
                try:
                    cliente = clienti.get(getattr(fascicolo, "id_cliente", "")) if getattr(fascicolo, "id_cliente", "") else None
                except (KeyError, ValueError, OSError):
                    cliente = None
                entita = entita_fascicolo(fascicolo, cliente, studio)
                for doc in atti_dello_studio(fascicolo):
                    testo = testo_indicizzato(indice, str(fascicolo.id), doc)
                    if len(testo.strip()) < 400:
                        saltati["senza testo indicizzato"] += 1
                        continue
                    righe.append(record(fascicolo, doc, testo, entita, sale))
                    tipi[righe[-1]["tipo_documento"] or "non indicato"] += 1
                    if a.limite and len(righe) >= a.limite:
                        break
    out = Path(a.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text("".join(json.dumps(r, ensure_ascii=False) + "\n" for r in righe), encoding="utf-8")
    riepilogo = {"atti": len(righe), "per_tipo": dict(tipi), "saltati": dict(saltati),
                 "sostituzioni": dict(sum((Counter(r["sostituzioni"]) for r in righe), Counter())),
                 "atti_con_residui": sum(1 for r in righe if r["residui"]), "file": str(out)}
    out.with_suffix(".riepilogo.json").write_text(json.dumps(riepilogo, ensure_ascii=False, indent=1), encoding="utf-8")
    print(json.dumps(riepilogo, ensure_ascii=False, indent=1))
    return 0


def _accetta_archiviati() -> bool:
    import inspect

    from pct.fascicoli import GestioneFascicoli
    return "archiviati" in inspect.signature(GestioneFascicoli.tutti).parameters


if __name__ == "__main__":
    raise SystemExit(main())
