"""Statistiche di stile degli atti dello studio (gira sul tuo PC; stampa solo numeri e formule, mai testi interi).

Uso: python3 analizza_stile.py atti_studio_anonimi.jsonl > stile_studio.json
Per ogni tipo di atto: numero, lunghezza, sezioni usate (intestazioni come «IN FATTO», «IN DIRITTO», «P.Q.M.»),
norme e precedenti più citati, formule ricorrenti (frasi di 4-8 parole presenti in almeno 5 atti diversi e
senza segnaposto di dati personali). Il risultato si può condividere: contiene solo frasi standard dell'atto.
"""
import json
import re
import sys
from collections import Counter, defaultdict

SEZIONE = re.compile(r"^\s*((?:IN\s+)?(?:FATTO|DIRITTO|MOTIVI|PREMESSO|CONCLUSIONI|P\.?\s?Q\.?\s?M\.?|ISTANZE(?:\s+ISTRUTTORIE)?|"
                     r"MEZZI\s+DI\s+PROVA|CHIEDE|CITA|RICORRE|ESPONE|SI\s+OPPONE|CONCLUDE|ALLEGATI|PER\s+QUESTI\s+MOTIVI|"
                     r"SVOLGIMENTO\s+DEL\s+PROCESSO|ECCEZIONI(?:\s+PRELIMINARI)?|NEL\s+MERITO)[^\n]{0,40})$", re.M | re.I)
NORMA = re.compile(r"art(?:t)?\.\s*\d+[\w-]*(?:\s*,\s*(?:comma|co\.)\s*\d+)?\s+(?:c\.?\s?c\.|c\.?\s?p\.?\s?c\.|c\.?\s?p\.|c\.?\s?p\.?\s?p\.|"
                   r"d\.?\s?lgs\.?\s*\d+/\d+|l\.\s*\d+/\d+|d\.?\s?p\.?\s?r\.?\s*\d+/\d+)", re.I)
PRECEDENTE = re.compile(r"(?:Cass\.|Cassazione)[^;\n]{0,80}?n\.\s*\d+/\d{2,4}", re.I)


def frasi(testo, n_min=4, n_max=8):
    parole = re.findall(r"[A-Za-zÀ-ù'’]+|[,.;:]", testo)
    out = set()
    for n in range(n_min, n_max + 1):
        for i in range(len(parole) - n):
            pezzo = parole[i:i + n]
            if all(re.fullmatch(r"[A-Za-zÀ-ù'’]+", p) for p in pezzo):
                out.add(" ".join(pezzo).lower())
    return out


def main(percorso):
    atti = [json.loads(r) for r in open(percorso, encoding="utf-8") if r.strip()]
    per_tipo = defaultdict(list)
    for a in atti:
        per_tipo[a.get("tipo_documento") or "non indicato"].append(a)
    report = {"atti": len(atti), "tipi": {}}
    for tipo, gruppo in sorted(per_tipo.items(), key=lambda x: -len(x[1])):
        sezioni, norme, prec, formule = Counter(), Counter(), Counter(), Counter()
        lunghezze = sorted(len(a["testo"]) for a in gruppo)
        for a in gruppo:
            t = a["testo"]
            sezioni.update({re.sub(r"\s+", " ", m.group(1).strip().upper())[:40] for m in SEZIONE.finditer(t)})
            norme.update({re.sub(r"\s+", " ", m.group(0).lower()) for m in NORMA.finditer(t)})
            prec.update({re.sub(r"\s+", " ", m.group(0)) for m in PRECEDENTE.finditer(t)})
            formule.update(f for f in frasi(t) if "[" not in f)
        soglia = max(5, len(gruppo) // 4)
        report["tipi"][tipo] = {
            "atti": len(gruppo), "caratteri_mediana": lunghezze[len(lunghezze) // 2],
            "sezioni": sezioni.most_common(15), "norme": norme.most_common(20), "precedenti": prec.most_common(10),
            "formule": [f for f, c in formule.most_common(400) if c >= soglia][:40],
            "atti_con_residui": sum(1 for a in gruppo if a.get("residui")),
        }
    json.dump(report, sys.stdout, ensure_ascii=False, indent=1)


if __name__ == "__main__":
    main(sys.argv[1])
