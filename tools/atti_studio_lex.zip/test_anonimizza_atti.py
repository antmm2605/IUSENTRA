from lex.dataset.anonimizza_atti import Pseudonimizzatore, residui

ATTO = """Il sig. Mario Rossi (C.F. RSSMRA80A01A662X), nato a Bari il 01/01/1980, residente in Via Sparano da Bari n. 12,
rappresentato dall'Avv. Giuseppe Verdi (PEC giuseppe.verdi@pec.ordineavvocatibari.it, tel. 080 5212345),
cita Edil Sud s.r.l. (P.IVA 01234567890), legale rappresentante Franco Neri; R.G. n. 1234/2025; sentenza n. 456/2024;
IBAN IT60X0542811101000000123456. Come chiarito da Cass., Sezioni Unite, sentenza n. 12946/2024, il ROSSI MARIO chiede."""


def test_dati_personali_sostituiti_e_coerenti():
    p = Pseudonimizzatore()
    out = p.anonimizza(ATTO, [("PERSONA", "Mario Rossi"), ("SOGGETTO", "Edil Sud s.r.l.")])
    for dato in ("Mario Rossi", "ROSSI MARIO", "RSSMRA80A01A662X", "Sparano", "Giuseppe Verdi", "giuseppe.verdi@", "5212345",
                 "01234567890", "Franco Neri", "1234/2025", "456/2024", "IT60X054", "01/01/1980", "Edil Sud"):
        assert dato not in out, dato
    assert out.count("[PERSONA_1]") == 2  # stessa persona, stesso segnaposto
    assert "sentenza n. 12946/2024" in out  # il precedente di Cassazione resta
    assert residui(out) == []
