"""Prepara gli esempi di addestramento dagli atti anonimizzati dello studio (gira sul tuo PC Ubuntu).

Uso: python3 prepara_atti_addestramento.py atti_studio_anonimi.jsonl --sistema v3/banco_v2.jsonl --out data/atti_studio_train.jsonl \
        [--tieni-con-residui controllati.txt] [--max-caratteri 6000]
Ogni atto si divide nelle sue sezioni (fatto, diritto, conclusioni...); ogni esempio chiede a Lex di scrivere una sezione
avendo davanti le sezioni precedenti dello stesso atto, così impara lo stile dello studio nel suo contesto. Gli atti con
residui non controllati si escludono: elenca in --tieni-con-residui gli id controllati a mano e da tenere comunque (uno per riga)
oppure correggi prima lo script di anonimizzazione. I segnaposto ([PERSONA_1]...) restano: Lex impara a non inventare.
"""
import argparse
import json
import random
import re

from analizza_stile import SEZIONE


def sezioni(testo):
    pos = [(m.start(), re.sub(r"\s+", " ", m.group(1).strip())) for m in SEZIONE.finditer(testo)]
    if len(pos) < 2:
        return []
    out = []
    for i, (inizio, titolo) in enumerate(pos):
        fine = pos[i + 1][0] if i + 1 < len(pos) else len(testo)
        corpo = testo[inizio:fine].strip()
        if len(corpo) > 200:
            out.append((titolo, corpo))
    return [("Intestazione", testo[:pos[0][0]].strip())] + out if pos[0][0] > 200 else out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("atti"); ap.add_argument("--sistema", required=True); ap.add_argument("--out", required=True)
    ap.add_argument("--tieni-con-residui", help="file con gli id controllati a mano da tenere anche se hanno residui")
    ap.add_argument("--max-caratteri", type=int, default=6000); ap.add_argument("--seme", type=int, default=20261022)
    a = ap.parse_args()
    sistema = json.loads(open(a.sistema, encoding="utf-8").readline())["messages"][0]["content"]
    tieni = set(open(a.tieni_con_residui).read().split()) if a.tieni_con_residui else set()
    righe, saltati = [], {"residui": 0, "senza_sezioni": 0}
    for riga in open(a.atti, encoding="utf-8"):
        atto = json.loads(riga)
        if atto.get("residui") and atto["id"] not in tieni:
            saltati["residui"] += 1
            continue
        parti = sezioni(atto["testo"])
        if not parti:
            saltati["senza_sezioni"] += 1
            continue
        for i, (titolo, corpo) in enumerate(parti):
            if i == 0 or len(corpo) > a.max_caratteri:
                continue
            contesto = "\n\n".join(c for _, c in parti[:i])[-a.max_caratteri:]
            domanda = (f"Domanda:\nScrivi la sezione «{titolo}» di un atto ({(atto.get('tipo_documento') or 'atto').lower()}, "
                       f"materia: {atto.get('materia') or 'non indicata'}), proseguendo il testo che segue. Usa solo i dati presenti; "
                       f"i dati personali restano come segnaposto.\n\nTesto precedente dell'atto:\n{contesto}")
            righe.append({"messages": [{"role": "system", "content": sistema}, {"role": "user", "content": domanda},
                                       {"role": "assistant", "content": corpo}]})
    random.Random(a.seme).shuffle(righe)
    with open(a.out, "w", encoding="utf-8") as f:
        f.write("".join(json.dumps(r, ensure_ascii=False) + "\n" for r in righe))
    print(json.dumps({"esempi": len(righe), "atti_saltati": saltati}, ensure_ascii=False))


if __name__ == "__main__":
    main()
