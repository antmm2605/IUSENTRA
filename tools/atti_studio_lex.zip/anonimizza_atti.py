"""Pseudonimizzazione degli atti dello studio prima che escano dal server per l'addestramento di Lex.

Art. 4 n. 5 e art. 89 Reg. UE 2016/679: i dati personali sono sostituiti con segnaposto coerenti nello stesso atto
(la stessa persona resta [PERSONA_1] in tutto il testo), senza tabella di corrispondenza: la corrispondenza non
esce dal processo e non viene salvata. Restano le norme, le formule e la struttura dell'atto.

Tre livelli:
1. entità note del fascicolo (cliente, controparte, avvocati, giudice, codici fiscali) passate dal chiamante;
2. dati con forma riconoscibile: codice fiscale, partita IVA, IBAN, e-mail e PEC, telefoni, numeri di ruolo,
   targhe, indirizzi, CAP, date di nascita, numeri di sentenze e atti di parte;
3. nomi propri non noti: coppie di parole con iniziale maiuscola precedute da un titolo (Sig., Avv., Dott. ...)
   o il cui primo elemento è un nome di persona italiano diffuso.
``residui`` segnala ciò che potrebbe essere sfuggito, per il controllo a campione prima dell'uso.
"""
from __future__ import annotations

import re
from collections.abc import Iterable

NOMI_PROPRI = {"Alessandro", "Alessandra", "Andrea", "Angela", "Angelo", "Anna", "Antonio", "Antonella", "Arturo", "Barbara", "Beatrice", "Benedetta", "Bruno", "Carla", "Carlo", "Caterina", "Chiara", "Claudia", "Claudio", "Cristina", "Cristian", "Daniela", "Daniele", "Davide", "Debora", "Domenico", "Donato", "Elena", "Elisa", "Elisabetta", "Emanuele", "Emma", "Enrico", "Enza", "Federica", "Federico", "Filippo", "Francesca", "Francesco", "Franco", "Gabriele", "Gabriella", "Giacomo", "Gianluca", "Gianni", "Giorgia", "Giorgio", "Giovanna", "Giovanni", "Giulia", "Giulio", "Giuseppe", "Giuseppina", "Grazia", "Ilaria", "Irene", "Laura", "Leonardo", "Lorenzo", "Luca", "Lucia", "Luciano", "Luigi", "Luisa", "Manuela", "Marco", "Maria", "Marina", "Mario", "Marta", "Martina", "Massimo", "Matteo", "Michela", "Michele", "Monica", "Nadia", "Nicola", "Nicoletta", "Paola", "Paolo", "Patrizia", "Pietro", "Raffaele", "Riccardo", "Rita", "Roberta", "Roberto", "Rocco", "Rosa", "Rosaria", "Salvatore", "Sara", "Serena", "Sergio", "Silvia", "Simona", "Simone", "Sofia", "Stefania", "Stefano", "Teresa", "Tommaso", "Valentina", "Valerio", "Vincenzo", "Vito", "Vittoria", "Vittorio", "Mariangela", "Pasquale", "Gaetano", "Cosimo", "Onofrio", "Nunzio", "Carmela", "Concetta", "Lucrezia", "Ottavio", "Saverio", "Ruggero"}
TITOLI = r"(?:Sig\.(?:ra)?|Sig\.na|Signor(?:a)?|Avv\.(?:to)?|Avvocato|Dott\.(?:ssa)?|Dottor(?:essa)?|Ing\.|Arch\.|Geom\.|Rag\.|Prof\.(?:ssa)?|Notaio|Giudice|G\.I\.|G\.U\.|on\.)"
_MAIUSC = r"[A-ZÀÈÉÌÒÙ][a-zàèéìòù'’]+(?:\s+(?:[A-ZÀÈÉÌÒÙ][a-zàèéìòù'’]+|[A-Z]{2,}))*"

FORME = [
    ("CODICE_FISCALE", re.compile(r"\b[A-Z]{6}\d{2}[A-EHLMPRST]\d{2}[A-Z]\d{3}[A-Z]\b", re.IGNORECASE)),
    ("IBAN", re.compile(r"\bIT\s?\d{2}\s?[A-Z]\s?(?:\d\s?){10}(?:[0-9A-Z]\s?){12}\b", re.IGNORECASE)),
    ("EMAIL", re.compile(r"\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b", re.IGNORECASE)),
    ("PARTITA_IVA", re.compile(r"(?i)(?:p\.?\s?iva|partita\s+iva|c\.?f\.?\s*e\s*p\.?\s?iva)\s*[:n.°]*\s*\d{11}\b|\b\d{11}\b")),
    ("TELEFONO", re.compile(r"(?<!\d)(?:\+39\s*)?(?:0\d{1,3}[\s./-]?\d{5,8}|3\d{2}[\s./-]?\d{6,7})(?!\d)")),
    ("RUOLO", re.compile(r"(?i)\b(?:R\.?\s?G\.?|N\.?\s?R\.?\s?G\.?|R\.?\s?G\.?\s?N\.?\s?R\.?|n\.\s*r\.\s*g\.)\s*(?:n\.?\s*)?\d{1,7}\s*/\s*\d{2,4}\b")),
    ("NUMERO_PROVVEDIMENTO", re.compile(r"(?i)\b(?:sentenza|ordinanza|decreto(?:\s+ingiuntivo)?|D\.I\.)\s+(?:n\.?|nr\.?|numero)\s*\d{1,6}\s*/\s*\d{2,4}\b")),
    ("TARGA", re.compile(r"\b[A-Z]{2}\s?\d{3}\s?[A-Z]{2}\b")),
    ("INDIRIZZO", re.compile(r"(?i)\b(?:via|viale|v\.le|piazza|p\.zza|corso|c\.so|largo|vicolo|contrada|c\.da|strada|località|loc\.)\s+"
                             r"[A-ZÀ-Ùa-zà-ù'’. ]{2,60}?(?:,?\s*(?:n\.?|nr\.?|civico)?\s*\d{1,4}[A-Za-z]?(?:/[A-Za-z0-9]+)?)?(?=[,;.\n)]|\s+-|\s+\d{5}|$)")),
    ("CAP", re.compile(r"\b\d{5}\b(?=\s+[A-ZÀ-Ù][a-zà-ù]+)")),
    ("DATA_NASCITA", re.compile(r"(?i)(nat[oa]\s+a\s+)([A-ZÀ-Ù][A-Za-zà-ù' ]{1,40}?)(\s*\(\w{2}\))?(\s+il\s+)(\d{1,2}[./-]\d{1,2}[./-]\d{2,4}|\d{1,2}\s+\w+\s+\d{4})")),
]

PRECEDENTE = re.compile(r"(?i)(Cass\.|Cassazione|Corte\s+(?:cost|di\s+cass|di\s+giust|europea|EDU)|Cons\.\s*St|Consiglio\s+di\s+Stato|C\.d\.S|SS\.\s*UU|Sez\.\s*Un|Sezioni\s+Unite|T\.A\.R\.|C\.G\.U\.E)")


class Pseudonimizzatore:
    """Sostituzioni coerenti nello stesso atto: stessa entità, stesso segnaposto."""

    def __init__(self) -> None:
        self._mappa: dict[str, str] = {}
        self._contatori: dict[str, int] = {}
        self.conteggi: dict[str, int] = {}

    def segnaposto(self, categoria: str, valore: str) -> str:
        chiave = f"{categoria}:{re.sub(r'\\s+', ' ', valore.strip().lower())}"
        if chiave not in self._mappa:
            self._contatori[categoria] = self._contatori.get(categoria, 0) + 1
            self._mappa[chiave] = f"[{categoria}_{self._contatori[categoria]}]"
        self.conteggi[categoria] = self.conteggi.get(categoria, 0) + 1
        return self._mappa[chiave]

    def _note(self, testo: str, entita: Iterable[tuple[str, str]]) -> str:
        voci = sorted({(c, v.strip()) for c, v in entita if v and len(v.strip()) >= 3}, key=lambda x: -len(x[1]))
        for categoria, valore in voci:
            varianti = {valore, valore.upper(), valore.title()}
            parti = valore.split()
            if len(parti) == 2:  # «Mario Rossi» e «Rossi Mario»
                varianti |= {f"{parti[1]} {parti[0]}", f"{parti[1]} {parti[0]}".upper()}
            for var in varianti:
                testo = re.sub(rf"(?<![\w\[]){re.escape(var)}(?![\w\]])", lambda _m, c=categoria, v=valore: self.segnaposto(c, v), testo)
        return testo

    def _provvedimenti(self, regex: re.Pattern, testo: str) -> str:
        """Numeri di provvedimenti della causa: i precedenti citati (Cassazione, Consiglio di Stato...) restano."""
        def sostituisci(m: re.Match) -> str:
            if PRECEDENTE.search(testo[max(0, m.start() - 60):m.start()]):
                return m.group(0)
            return self.segnaposto("NUMERO_PROVVEDIMENTO", m.group(0))
        return regex.sub(sostituisci, testo)

    def anonimizza(self, testo: str, entita: Iterable[tuple[str, str]] = ()) -> str:
        testo = self._note(str(testo or ""), entita)
        for categoria, regex in FORME:
            if categoria == "DATA_NASCITA":
                testo = regex.sub(lambda m: f"{m.group(1)}{self.segnaposto('LUOGO', m.group(2))}{m.group(4)}{self.segnaposto('DATA_NASCITA', m.group(5))}", testo)
            elif categoria == "NUMERO_PROVVEDIMENTO":
                # i precedenti citati (Cassazione, Corte costituzionale, Consiglio di Stato...) restano: sono pubblici
                testo = self._provvedimenti(regex, testo)
            else:
                testo = regex.sub(lambda m, c=categoria: self.segnaposto(c, m.group(0)), testo)
        testo = re.sub(rf"\b({TITOLI})\s+({_MAIUSC})", lambda m: f"{m.group(1)} {self.segnaposto('PERSONA', m.group(2))}", testo)
        testo = re.sub(rf"\b((?:{'|'.join(sorted(NOMI_PROPRI))}))\s+([A-ZÀ-Ù][a-zà-ù'’]+(?:\s+[A-ZÀ-Ù][a-zà-ù'’]+)?)\b",
                       lambda m: self.segnaposto("PERSONA", m.group(0)), testo)
        testo = re.sub(r"\b([A-ZÀ-Ù]{2,}(?:\s+[A-ZÀ-Ù]{2,}){1,2})\b(?=\s*(?:,|\(|nat[oa]|residente|C\.?F\.?))",
                       lambda m: self.segnaposto("PERSONA", m.group(1)), testo)
        return testo


def residui(testo: str) -> list[str]:
    """Indizi di dati personali rimasti: coppie di parole maiuscole non giuridiche e cifre lunghe."""
    giuridiche = {"Corte", "Tribunale", "Cassazione", "Sezioni", "Unite", "Consiglio", "Stato", "Repubblica", "Codice",
                  "Civile", "Penale", "Procedura", "Legge", "Decreto", "Giudice", "Pace", "Appello", "Ufficio", "Agenzia",
                  "Entrate", "Ministero", "Giustizia", "Regione", "Comune", "Provincia", "Italia", "Italiana", "Ill", "Ecc",
                  "Voglia", "Piaccia", "Lavoro", "Previdenza", "Istituto", "Nazionale", "Sociale", "Europea", "Unione", "Costituzione"}
    sospetti = []
    for m in re.finditer(r"\b([A-ZÀ-Ù][a-zà-ù]{2,})\s+([A-ZÀ-Ù][a-zà-ù]{2,})\b", testo):
        if m.group(1) not in giuridiche and m.group(2) not in giuridiche:
            sospetti.append(m.group(0))
    sospetti += re.findall(r"\b\d{8,}\b", testo)
    return sorted(set(sospetti))
